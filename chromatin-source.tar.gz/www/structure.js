function initStructure(canvasId, geometryMessage, resetMessage) {
 const canvas=document.getElementById(canvasId),ctx=canvas.getContext("2d");
 canvas.setAttribute("aria-label","Inferred chromatin model. Use arrow keys to rotate.");
 let p=[], step=25000;
let rx=.55,ry=.7,zoom=1,drag=null;
function draw(){
 const dpr=window.devicePixelRatio||1,w=canvas.clientWidth,h=canvas.clientHeight;
 canvas.width=w*dpr;canvas.height=h*dpr;ctx.scale(dpr,dpr);
 if(!p.length) return;
 const max=Math.max(...p.map(q=>Math.hypot(...q.slice(1,4))));
 const s=Math.min(w,h)*.35*zoom/max;
 const nodes=p.map(([start,x,y,z,anchor],i)=>{
  const u=x*Math.cos(ry)+z*Math.sin(ry),v=-x*Math.sin(ry)+z*Math.cos(ry);
  return {x:w/2+u*s,y:h/2+(y*Math.cos(rx)-v*Math.sin(rx))*s,
          z:y*Math.sin(rx)+v*Math.cos(rx),start,anchor,i};
 });
 const color=i=>"hsl("+(214-77*i/(p.length-1))+" 64% 41%)";
 const pieces=[];
 nodes.forEach((a,i)=>{
  if(i&&a.start-nodes[i-1].start===step){
   const b=nodes[i-1];pieces.push({z:(a.z+b.z)/2,paint:()=>{
    ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(a.x,a.y);ctx.strokeStyle=color(i);ctx.lineWidth=2;ctx.stroke();
   }});
  }
  pieces.push({z:a.z,paint:()=>{
   ctx.beginPath();ctx.arc(a.x,a.y,a.anchor?7:3.8,0,2*Math.PI);ctx.fillStyle=a.anchor?"#AD3529":color(i);ctx.fill();
   if(a.anchor){ctx.strokeStyle="#fff";ctx.lineWidth=1.5;ctx.stroke();}
  }});
 });
 pieces.sort((a,b)=>a.z-b.z).forEach(o=>o.paint());

}
function reset(){rx=.55;ry=.7;zoom=1;draw();}
canvas.addEventListener("pointerdown",e=>{drag=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId);});
canvas.addEventListener("pointermove",e=>{if(drag){ry+=(e.clientX-drag[0])*.012;rx+=(e.clientY-drag[1])*.012;drag=[e.clientX,e.clientY];draw();}});
for(const ev of ["pointerup","pointercancel"])canvas.addEventListener(ev,()=>{drag=null;});
canvas.addEventListener("wheel",e=>{e.preventDefault();zoom=Math.max(.45,Math.min(2.4,zoom*Math.exp(-e.deltaY*.001)));draw();},{passive:false});
canvas.addEventListener("keydown",e=>{switch(e.key){case"ArrowLeft":ry-=.15;break;case"ArrowRight":ry+=.15;break;case"ArrowUp":rx-=.15;break;case"ArrowDown":rx+=.15;break;case"+":case"=":zoom=Math.min(2.4,zoom*1.1);break;case"-":zoom=Math.max(.45,zoom/1.1);break;default:return;}e.preventDefault();draw();});

 Shiny.addCustomMessageHandler(geometryMessage, ({nodes,binSize}) => {
  step=binSize||25000;
  p=(nodes||[]).map(n=>[n.start,n.x,n.y,n.z,n.anchor]);
  reset();
 });
 if(resetMessage) Shiny.addCustomMessageHandler(resetMessage, (_message) => reset());
 new ResizeObserver(draw).observe(canvas);
}
document.addEventListener("DOMContentLoaded", () => {
 initStructure("structure", "geometry", "reset_geometry");
 initStructure("cohort_structure", "cohort_geometry", "cohort_reset_geometry");
 for(const id of ["HeLaS3_DMSO","HeLaS3_ICRF193"]) initStructure(id+"_canvas",id+"_geometry");
});
