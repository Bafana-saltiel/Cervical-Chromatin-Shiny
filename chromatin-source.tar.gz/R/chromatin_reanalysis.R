reanalysis_root <- normalizePath(".", mustWork=TRUE)

reanalysis_ui <- function() {
  tabPanel("Hi-C reanalysis",
    tags$section(class="card wide",
      radioButtons("re_source","Data source", c("HeLa-S3 study","Upload study"), inline=TRUE),
      conditionalPanel("input.re_source === 'HeLa-S3 study'",
        p("GSE198610 balanced Hi-C, chr14 at 250 kb. Compare DMSO and ICRF-193 samples at 4 or 8 hours. Example loci have no assigned differential-expression status."),
        p("The MC-3C panel uses the authors’ deposited C-walk table. Hi-C supplies the structural annotations."),
        tags$a("Hildebrand et al. · GEO",href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE198610")),
      conditionalPanel("input.re_source === 'Upload study'",
        p("Use balanced cis contacts, explicit zeroes and one assembly. Use matching zero-based BED6 gene coordinates or a CSV with gene, chromosome, tss0, assembly and optional gene_id and group. For BED6, add an optional seventh group column. Use one row per gene and DEG group. For separate BED6 files, the filename identifies the DEG group."),
        div(class="controls",
          fileInput("re_contacts","Contacts (CSV or CSV.gz)",accept=c(".csv",".gz")),
          fileInput("re_samples","Sample metadata (CSV)",accept=".csv"),
          fileInput("re_genes","Gene or DEG lists (CSV or BED6)",accept=c(".csv",".bed"),multiple=TRUE),
          fileInput("re_phase","Optional A/B phasing track (CSV)",accept=".csv"),
          fileInput("re_features","Optional CTCF or enhancer BED4",accept=".bed")),
        p("Phasing CSV columns are chromosome, bin, activity and assembly. Use bin starts and a track with higher values in active chromatin. Name regulatory BED intervals by feature or assay and use the same genome assembly.")),
      div(class="controls",selectInput("re_control","Reference sample",NULL),
          selectInput("re_compare","Comparison sample",NULL),
          selectInput("re_chr","Chromosome",NULL),selectInput("re_gene","Promoter",NULL),
          numericInput("re_window","Insulation window (bins)",5,min=2,max=20,step=1)),
      downloadButton("re_bundle","Download reanalysis ZIP"),
      downloadButton("re_example_genes","Example gene CSV"),
      textOutput("re_status")),
    tags$section(class="card wide",
      tabsetPanel(
        tabPanel("Locus overview",
          h3(textOutput("re_locus_title",inline=TRUE)),
          numericInput("re_locus_flank","Flank on each side (Mb)",5,min=.25,max=100,step=.25),
          tableOutput("re_locus_summary"),
          h4("Local contact maps"),plotOutput("re_locus_maps",height=400),
          h4("Local insulation and compartment scores"),
          p("Dashed line marks the TSS. Dotted lines mark candidate boundaries. Shading marks the candidate TAD containing the TSS when available."),
          plotOutput("re_locus_tracks",height=465),
          h4("Local promoter contacts"),plotOutput("re_locus_promoter",height=410),
          h4("Candidate promoter contacts in this window"),
          tableOutput("re_locus_peaks")),
        tabPanel("Contact maps",plotOutput("re_maps",height=440)),
        tabPanel("TADs and compartments",plotOutput("re_tracks",height=650)),
        tabPanel("Promoter contacts",plotOutput("re_promoter",height=500),tableOutput("re_peaks")),
        tabPanel("DEG annotations",tableOutput("re_annotation")),
        tabPanel("MC-3C",p("First-pair cis distances by biological sample. Fractions use pairs with separation ≥1 kb. This is a descriptive MC-3C distribution."),
          plotOutput("re_mc",height=500))),
      tags$details(tags$summary("Analysis and interpretation"),
        p("Insulation minima mark candidate TAD boundaries. Compartment signs are descriptive classes unless phased with an activity track. Promoter peaks are local enrichments, with no significance or enhancer assignment inferred from Hi-C alone. Read depth, normalization and biological replication govern which comparisons can support inference."))))
}

read_reanalysis_genes <- function(file, assembly) {
  if (endsWith(tolower(file$name),".bed")) {
    d <- read.delim(file$datapath,header=FALSE,comment.char="#",quote="")
    stopifnot(ncol(d)%in%c(6L,7L),all(d[[6]]%in%c("+","-")),all(d[[2]]>=0 & d[[3]]>d[[2]]))
    return(data.frame(gene=d[[4]],chromosome=d[[1]],tss0=ifelse(d[[6]]=="+",d[[2]],d[[3]]-1),
                      assembly=assembly,group=if(ncol(d)==7L) d[[7]] else tools::file_path_sans_ext(basename(file$name))))
  }
  read.csv(file$datapath,stringsAsFactors=FALSE)
}

reanalysis_structure <- function(m,bins,width,w,activity=NULL) {
  n <- nrow(m)
  offset <- abs(row(m)-col(m))
  denominator <- as.numeric(tapply(m,offset,mean,na.rm=TRUE))
  oe <- m / denominator[offset+1L]
  oe[offset<=1L | !is.finite(oe)] <- NA_real_
  insulation <- rep(NA_real_,n)
  if (n>=2*w) for (k in seq.int(w+1L,n-w+1L)) {
    cross <- oe[(k-w):(k-1L), k:(k+w-1L),drop=FALSE]
    ok <- is.finite(cross)
    if (mean(ok)>=.7 && mean(cross[ok])>0) insulation[k] <- log2(mean(cross[ok]))
  }
  boundaries <- which(vapply(seq_len(n),function(k) {
    if (!is.finite(insulation[k]) || k<=2L || k>=n-1L) return(FALSE)
    local <- insulation[(k-2L):(k+2L)]
    all(is.finite(local)) && insulation[k]==min(local) &&
      sum(local==insulation[k])==1L && insulation[k]<0
  },logical(1)))
  usable <- which(rowMeans(is.finite(oe))>=.70)
  pc <- rep(NA_real_,n)
  if (length(usable)>=8L) {
    x <- oe[usable,usable,drop=FALSE]
    x[!is.finite(x)] <- 1
    r <- suppressWarnings(cor(t(x)))
    r[!is.finite(r)] <- 0
    if (any(abs(r[row(r)!=col(r)])>0)) pc[usable] <- eigen(r,symmetric=TRUE)$vectors[,1]
  }
  association <- function(a,b) {
    valid <- is.finite(a) & is.finite(b)
    if(sum(valid)<8L) return(NA_real_)
    suppressWarnings(cor(a[valid],b[valid]))
  }
  phase <- if(is.null(activity)) NA_real_ else association(pc,activity)
  phased <- is.finite(phase) && abs(phase)>=.2
  if(phased && phase<0) pc <- -pc
  list(insulation=insulation,boundaries=boundaries,pc=pc,oe=oe,phased=phased,
       phase_r=if(phased) abs(phase) else phase)
}

reanalysis_chromosome <- function(view, genes, w, phase=NULL, features=NULL) {
  bins <- view$bins; width <- view$width
  activity <- if (!is.null(phase)) {
    p <- phase[phase$chromosome==view$chr,]
    p$activity[match(bins,p$bin)]
  }
  structure <- lapply(view$maps,reanalysis_structure,bins=bins,width=width,w=w,activity=activity)
  a <- structure[[1]]; b <- structure[[2]]
  cov <- is.finite(a$pc)&is.finite(b$pc)
  aligned <- FALSE
  if(!a$phased && !b$phased && sum(cov)>=8L) {
    r <- suppressWarnings(cor(a$pc[cov],b$pc[cov]))
    aligned <- is.finite(r) && abs(r)>=.2
    if(aligned && r<0) b$pc <- -b$pc
  }
  structure[[2]] <- b
  classes <- lapply(structure,function(s)
    ifelse(!is.finite(s$pc) | s$pc==0,NA_character_,
      if(s$phased) ifelse(s$pc>0,"A","B") else ifelse(s$pc>0,"PC1+","PC1-")))
  change <- if ((a$phased && b$phased) || aligned)
    ifelse(is.na(classes[[1]]) | is.na(classes[[2]]),NA_character_,
           paste(classes[[1]],classes[[2]],sep=" to ")) else rep(NA_character_,length(bins))
  track <- do.call(rbind,lapply(1:2,function(i) {
    s <- structure[[i]]
    data.frame(sample_id=view$ids[i],chromosome=view$chr,start=bins,end=bins+width,
               insulation=s$insulation,boundary=seq_along(bins)%in%s$boundaries,
               pc1=s$pc,compartment=classes[[i]],phasing_correlation=s$phase_r,
               comparison_class=change)
  }))
  domains <- function(s,id) {
    edges <- bins[s$boundaries]
    data.frame(chromosome=rep(view$chr,max(0,length(edges)-1L)),
               start=head(edges,-1L),end=tail(edges,-1L),sample_id=rep(id,max(0,length(edges)-1L)))
  }
  tad <- do.call(rbind,Map(domains,structure,view$ids))
  boundaries <- track[track$boundary,c("sample_id","chromosome","start","insulation")]
  boundaries$nearest_other_bp <- vapply(seq_len(nrow(boundaries)),function(j) {
    other <- boundaries$start[boundaries$sample_id!=boundaries$sample_id[j]]
    if(length(other)) min(abs(other-boundaries$start[j])) else NA_real_
  },numeric(1))
  boundaries$conserved_within_one_bin <- boundaries$nearest_other_bp<=width

  overlap <- function(start) {
    if(is.null(features)) return(NA_character_)
    hits <- features$feature[features$chromosome==view$chr & features$start < start+width & features$end > start]
    paste(unique(hits),collapse=";")
  }
  focal <- function(k,z,oe) {
    n <- nrow(oe)
    if(k<=2L || k>=n-1L) return(NA_real_)
    vertical <- oe[k+c(-2L,-1L,1L,2L),z]
    donut <- oe[(k-2L):(k+2L),(z-2L):(z+2L),drop=FALSE]
    donut[3L,] <- donut[,3L] <- NA_real_
    if(!all(is.finite(vertical)) || sum(is.finite(donut))<12L) return(NA_real_)
    background <- max(median(vertical),median(donut,na.rm=TRUE))
    if(background>0) oe[k,z]/background else NA_real_
  }
  rows <- vector("list",2*nrow(genes))
  profiles <- peaks <- rows
  for(i in 1:2) for(j in seq_len(nrow(genes))) {
    key <- (i-1L)*nrow(genes)+j
    g <- genes[j,]; s <- structure[[i]]; m <- view$maps[[i]]
    k <- match(floor(g$tss0/width)*width,bins)
    domain <- tad[tad$sample_id==view$ids[i] & tad$start<=g$tss0 & tad$end>g$tss0,]
    bb <- bins[s$boundaries]
    observed <- !is.na(k) && any(is.finite(m[k,-k]))
    rows[[key]] <- data.frame(g,sample_id=view$ids[i],
      status=if(observed) "Covered" else "Insufficient promoter coverage",
      tad_start=if(observed) domain$start[1] else NA_real_,
      tad_end=if(observed) domain$end[1] else NA_real_,
      boundary_distance_bp=if(observed && length(bb)) min(abs(bb-g$tss0)) else NA_real_,
      pc1=s$pc[k],compartment=classes[[i]][k],comparison_class=change[k],candidate_peaks=NA_integer_,focal_contacts=NA_integer_)
    if(!observed) next
    profile <- data.frame(record_id=g$record_id,gene=g$gene,sample_id=view$ids[i],chromosome=view$chr,
                          promoter_start=bins[k],distal_start=bins,distal_end=bins+width,
                          separation_bp=abs(bins-bins[k]),balanced=m[k,],oe=s$oe[k,])
    y <- profile$oe
    hit <- which(vapply(seq_along(y),function(z) {
      if(z<=2L || z>=length(y)-1L || abs(k-z)<3L || !is.finite(y[z]) || y[z]<1.5) return(FALSE)
      nearby <- y[c(z-2L,z-1L,z+1L,z+2L)]
      all(is.finite(nearby)) && y[z]>max(nearby) && y[z]>=1.5*median(nearby)
    },logical(1)))
    profile$candidate_peak <- seq_along(y)%in%hit
    profile$focal_enrichment <- NA_real_
    profile$focal_enrichment[hit] <- vapply(hit,function(z) focal(k,z,s$oe),numeric(1))
    profile$focal_candidate <- is.finite(profile$focal_enrichment) & profile$focal_enrichment>=1.5
    peaks[[key]] <- profile[hit,]
    peaks[[key]]$promoter_features <- rep(overlap(bins[k]),length(hit))
    peaks[[key]]$distal_features <- vapply(bins[hit],overlap,character(1))
    rows[[key]]$focal_contacts <- sum(profile$focal_candidate)
    rows[[key]]$candidate_peaks <- length(hit)
    profiles[[key]] <- profile
  }
  list(view=view,track=track,tad=tad,boundaries=boundaries,annotation=do.call(rbind,rows),
       profiles=do.call(rbind,profiles),peaks=do.call(rbind,peaks))
}

draw_reanalysis_tracks <- function(result,labels,tss=NULL,annotation=NULL) {
  par(mfrow=c(2,2),mar=c(4,4,3,1))
  for (column in c("insulation","pc1")) for (id in result$view$ids) {
    d <- result$track[result$track$sample_id==id,]
    y <- d[[column]]
    if(!any(is.finite(y))) {
      plot.new(); title(labels[[id]]); text(.5,.5,paste(column,"unavailable")); next
    }
    plot(d$start/1e6,y,type="n",
         xlab=paste(result$view$chr,"(Mb)"),ylab=column,main=labels[[id]])
    domain <- if (!is.null(annotation)) annotation[annotation$sample_id==id,c("tad_start","tad_end")]
    if(!is.null(domain) && nrow(domain) && all(is.finite(unlist(domain)))) {
      usr <- par("usr")
      rect(domain$tad_start/1e6,usr[3],domain$tad_end/1e6,usr[4],col="#edf2f5",border=NA)
    }
    lines(d$start/1e6,y,type=if(column=="insulation") "l" else "h",
         col=if(column=="insulation") "#007e88" else ifelse(y>=0,"#007e88","#bf5040"))
    if(column=="insulation") abline(v=d$start[d$boundary]/1e6,col="#bf5040",lty=3)
    else abline(h=0,col="#758490")
    if(!is.null(tss)) abline(v=tss/1e6,lty=2,col="#303941")
  }
}

draw_reanalysis_promoter <- function(d,labels) {
  par(mfrow=c(2,1),mar=c(4,4,2,1))
  for (column in c("balanced","oe")) {
    if(is.null(d) || !nrow(d) || !any(is.finite(d[[column]]))) {
      plot.new(); text(.5,.5,"Promoter profile unavailable"); next
    }
    plot(range(d$distal_start)/1e6,range(d[[column]],finite=TRUE),type="n",
         xlab=paste(d$chromosome[1],"(Mb)"),ylab=if(column=="oe") "Observed / expected" else "Balanced contact")
    colors <- setNames(c("#007e88","#bf5040"),names(labels))
    for (id in unique(d$sample_id)) {
      v <- d[d$sample_id==id,]
      lines(v$distal_start/1e6,v[[column]],col=colors[[id]],lwd=1.4)
      hits <- v$candidate_peak
      points(v$distal_start[hits]/1e6,v[[column]][hits],col=colors[[id]],pch=16,cex=.65)
    }
    abline(v=d$promoter_start[1]/1e6,lty=3)
    legend("topright",labels,col=colors,lty=1,bty="n",cex=.75)
  }
}

draw_reanalysis_mc <- function(d) {
  if (!nrow(d)) {plot.new(); text(.5,.5,"MC-3C profiles unavailable"); return(invisible(NULL))}
  d <- d[order(d$separation_lower_bp),]
  samples <- split(d,d$sample_id)
  colors <- hcl.colors(length(samples),"Dark 3")
  fraction <- d$pairs/ave(d$pairs,d$sample_id,FUN=sum)
  par(mar=c(5,5,4,1))
  plot(d$separation_lower_bp,fraction,type="n",log="x",
    xlab="Genomic separation, lower edge (bp)",ylab="Fraction of first cis pairs",
    main="MC-3C distance distribution by sample")
  for(i in seq_along(samples)) {
    v <- samples[[i]]
    lines(v$separation_lower_bp,v$pairs/sum(v$pairs),col=colors[i],lwd=1.3)
  }
  legend("topright",names(samples),col=colors,lty=1,ncol=2,bty="n",cex=.58)
}

serve_reanalysis <- function(input,output,session) {
  example <- file.path(reanalysis_root,"data/reanalysis_example_genes.csv")
  stored <- eventReactive(list(input$re_source,input$re_contacts,input$re_samples,input$re_genes,input$re_phase,input$re_features), {
    ex <- identical(input$re_source,"HeLa-S3 study")
    tryCatch({
      if(ex) {
        contacts <- read.csv(gzfile(experiment_example_contacts_path))
        samples <- read.csv(experiment_example_samples_path)
      } else {
        req(input$re_contacts,input$re_samples,input$re_genes)
        contacts <- read_experiment_csv(input$re_contacts)
        samples <- read_experiment_csv(input$re_samples)
      }
      d <- validate_experiment(contacts,samples)
      assembly <- d$samples$assembly[1]
      g <- if(ex) read.csv(example) else {
        files <- input$re_genes
        do.call(rbind,lapply(seq_len(nrow(files)),function(i) {
          x <- read_reanalysis_genes(files[i,],assembly)
          if(!"gene_id"%in%names(x)) x$gene_id <- NA_character_
          if(!"group"%in%names(x)) x$group <- tools::file_path_sans_ext(basename(files$name[i]))
          x[c("gene","chromosome","tss0","assembly","gene_id","group")]
        }))
      }
      stopifnot("Gene table needs gene, chromosome, tss0 and matching assembly"=
        all(c("gene","chromosome","tss0","assembly")%in%names(g)) && nrow(g)>0 &&
        !anyNA(g$gene) && all(nzchar(g$gene)) && !anyNA(g$chromosome) &&
        is.numeric(g$tss0) && all(is.finite(g$tss0)&g$tss0>=0&g$tss0%%1==0) &&
        !anyNA(g$assembly) && all(g$assembly==assembly))
      if(!"gene_id"%in%names(g)) g$gene_id <- NA_character_
      if(!"group"%in%names(g)) g$group <- "Uploaded"
      g <- g[c("gene","gene_id","group","chromosome","tss0","assembly")]
      g$record_id <- seq_len(nrow(g))
      phase <- NULL
      if (!ex && !is.null(input$re_phase)) {
        phase <- read.csv(input$re_phase$datapath)
        stopifnot("Invalid phasing track"=
          all(c("chromosome","bin","activity","assembly")%in%names(phase)) &&
          !anyNA(phase[c("chromosome","assembly","bin")]) && all(phase$assembly==assembly) &&
          is.numeric(phase$bin) && is.numeric(phase$activity) &&
          !anyDuplicated(phase[c("chromosome","bin")]))
      }
      features <- NULL
      if (!ex && !is.null(input$re_features)) {
        features <- read.delim(input$re_features$datapath,header=FALSE,comment.char="#",quote="")
        stopifnot("Use BED4 for regulatory intervals"=ncol(features)==4L)
        names(features) <- c("chromosome","start","end","feature")
        stopifnot("Invalid regulatory BED intervals"=is.numeric(features$start) && is.numeric(features$end) &&
          all(is.finite(features$start)&is.finite(features$end)&features$start>=0&features$end>features$start) &&
          !anyNA(features$feature))
      }
      c(d,list(genes=g,phase=phase,features=features,example=ex))
    },error=function(e) {
      if(inherits(e,"shiny.silent.error")) stop(e)
      validate(need(FALSE,conditionMessage(e)))
    })
  })
  observeEvent(stored(), {
    s <- stored()$samples
    labels <- setNames(s$sample_id,paste(s$condition,s$time_hours,"h ·",s$sample_id))
    updateSelectInput(session,"re_control",choices=labels,selected=s$sample_id[1])
    updateSelectInput(session,"re_compare",choices=labels,selected=s$sample_id[2])
  })
  selected <- reactive({
    d <- stored()
    req(input$re_control,input$re_compare)
    ids <- c(input$re_control,input$re_compare)
    s <- d$samples[match(ids,d$samples$sample_id),]
    validate(need(!anyNA(s$sample_id)&&ids[1]!=ids[2],"Select two different samples."))
    list(ids=ids,labels=setNames(paste(s$condition,s$time_hours,"h ·",ids),ids))
  })
  chromosomes <- reactive({
    d <- stored(); ids <- selected()$ids
    intersect(d$contacts$chromosome[d$contacts$sample_id==ids[1]],
              d$contacts$chromosome[d$contacts$sample_id==ids[2]]) |> unique() |> sort()
  })
  observeEvent(chromosomes(),updateSelectInput(session,"re_chr",choices=chromosomes(),selected=chromosomes()[1]))
  observeEvent(list(stored(),input$re_chr), {
    g <- stored()$genes
    g <- g[g$chromosome==req(input$re_chr),]
    updateSelectInput(session,"re_gene",choices=setNames(g$record_id,paste(g$gene,g$group,sep=" · ")))
  })
  fit <- function(chr) {
    d <- stored()
    w <- req(input$re_window)
    validate(need(is.finite(w) && w>=2 && w<=20 && w%%1==0,"Choose an integer insulation window of 2–20 bins."))
    view <- experiment_maps(d,chr,selected()$ids)
    reanalysis_chromosome(view,d$genes[d$genes$chromosome==chr,],w,d$phase,d$features)
  }
  current <- reactive(fit(req(input$re_chr)))
  # Retain every gene record even if the selected samples lack a comparable map.
  unavailable <- function(genes,reason) {
    do.call(rbind,lapply(selected()$ids,function(id) data.frame(genes,sample_id=id,
      status=reason,tad_start=NA_real_,tad_end=NA_real_,boundary_distance_bp=NA_real_,
      pc1=NA_real_,compartment=NA_character_,comparison_class=NA_character_,candidate_peaks=NA_integer_,focal_contacts=NA_integer_)))
  }
  output$re_status <- renderText({
    d <- stored()
    paste(nrow(d$genes),"gene records ·",length(chromosomes()),
      "shared chromosomes or regions ·",d$samples$assembly[1],"· descriptive sample comparison")
  })
  locus <- reactive({
    result <- current()
    a <- result$annotation
    key <- req(input$re_gene)
    a <- a[a$record_id==key,]
    validate(need(nrow(a)>0,"Select a promoter on this chromosome."))
    tss <- a$tss0[1]
    flank <- req(input$re_locus_flank)*1e6
    validate(need(is.finite(flank) && flank>=250000 && flank<=100e6,
                  "Choose a flank between 0.25 and 100 Mb."))
    keep <- abs(result$view$bins+result$view$width/2-tss)<=flank
    view <- result$view
    view$bins <- view$bins[keep]
    view$maps <- lapply(view$maps,function(m) m[keep,keep,drop=FALSE])
    result$view <- view
    result$track <- result$track[result$track$start%in%view$bins,]
    local_gene <- function(d) {
      if(is.null(d)) return(NULL)
      d[d$record_id==key & d$distal_start%in%view$bins,]
    }
    result$profiles <- local_gene(result$profiles)
    result$peaks <- local_gene(result$peaks)
    result$annotation <- a
    result
  })
  output$re_locus_title <- renderText({
    a <- locus()$annotation[1,]
    paste(a$gene,a$gene_id,"·",paste0(a$chromosome,":",format(a$tss0,big.mark=",",scientific=FALSE)),
          "·",a$assembly,"· zero-based TSS")
  })
  output$re_locus_summary <- renderTable({
    a <- locus()$annotation
    data.frame(Sample=unname(selected()$labels[a$sample_id]),Coverage=a$status,
               `TAD start`=a$tad_start,`TAD end`=a$tad_end,
               `Boundary distance (bp)`=a$boundary_distance_bp,PC1=a$pc1,
               Compartment=a$compartment,Change=a$comparison_class,
               `Candidate peaks`=a$candidate_peaks,`Focal contacts`=a$focal_contacts,
               check.names=FALSE)
  },digits=3,na="—")
  output$re_locus_maps <- renderPlot({
    view <- locus()$view
    validate(need(length(view$bins)>=2L,"Increase the flank or choose a locus with coverage."))
    draw_experiment(view,"maps",selected()$labels)
  })
  output$re_locus_tracks <- renderPlot({
    d <- locus()
    validate(need(length(d$view$bins)>0,"No map bins in this window."))
    draw_reanalysis_tracks(d,selected()$labels,d$annotation$tss0[1],d$annotation)
  })
  output$re_locus_promoter <- renderPlot(draw_reanalysis_promoter(locus()$profiles,selected()$labels))
  output$re_locus_peaks <- renderTable({
    p <- locus()$peaks
    validate(need(!is.null(p) && nrow(p)>0,"No candidate promoter contacts in this window."))
    p <- p[order(!p$focal_candidate,-p$oe),]
    p[c("sample_id","distal_start","distal_end","separation_bp","balanced","oe",
        "focal_enrichment","focal_candidate","promoter_features","distal_features")]
  },digits=5,na="—")
  output$re_maps <- renderPlot(draw_experiment(current()$view,"maps",selected()$labels))
  output$re_tracks <- renderPlot(draw_reanalysis_tracks(current(),selected()$labels))
  output$re_promoter <- renderPlot({
    p <- current()$profiles
    draw_reanalysis_promoter(p[p$record_id==input$re_gene,],selected()$labels)
  })
  output$re_peaks <- renderTable({
    p <- current()$peaks
    req(!is.null(p))
    p[p$record_id==input$re_gene,c("sample_id","distal_start","separation_bp","balanced","oe","focal_candidate","distal_features")]
  })
  output$re_annotation <- renderTable(current()$annotation, digits=3)
  mc <- reactive({
    validate(need(stored()$example,"MC-3C reference profiles are available with the HeLa-S3 example."))
    read.csv(file.path(reanalysis_root,"data/reanalysis_mc3c.csv"))
  })
  output$re_mc <- renderPlot(draw_reanalysis_mc(mc()))
  output$re_example_genes <- downloadHandler(function() "HeLaS3_example_genes.csv",function(path) file.copy(example,path))
  output$re_bundle <- downloadHandler(function() "HiC_reanalysis.zip",function(path) {
    d <- stored()
    base <- tempfile("hic-reanalysis-")
    dir.create(base)
    on.exit(unlink(base,recursive=TRUE),add=TRUE)
    write <- function(name,data) write.csv(if(is.null(data)) data.frame(status=character()) else data,
                                          file.path(base,name),row.names=FALSE,na="")
    chr <- chromosomes()
    results <- lapply(chr,function(c) tryCatch(fit(c),shiny.silent.error=function(e) conditionMessage(e)))
    names(results) <- chr
    good <- vapply(results,is.list,logical(1))
    skipped <- data.frame(chromosome=chr[!good],reason=as.character(unlist(results[!good])))
    write("skipped_regions.csv",skipped)
    collect <- function(k) do.call(rbind,lapply(results[good],`[[`,k))
    outside <- d$genes[!d$genes$chromosome%in%chr[good],]
    ann <- rbind(collect("annotation"),if(nrow(outside)) unavailable(outside,"No comparable chromosome or region"))
    write("gene_annotations.csv",ann[order(ann$record_id,match(ann$sample_id,selected()$ids)),])
    counts <- ann[c("sample_id","group","status","compartment","comparison_class")]
    counts[] <- lapply(counts,function(x) ifelse(is.na(x),"Unavailable",x))
    counts$records <- 1L
    write("DEG_group_summary.csv",aggregate(records~.,data=counts,FUN=sum))
    write("insulation_and_compartments.csv",collect("track"))
    write("candidate_boundaries.csv",collect("boundaries"))
    profiles <- collect("profiles")
    write("virtual_4C.csv",profiles)
    if(!is.null(profiles)) {
      key <- c("record_id","gene","chromosome","promoter_start","distal_start","distal_end","separation_bp")
      a <- profiles[profiles$sample_id==selected()$ids[1],c(key,"balanced","oe")]
      b <- profiles[profiles$sample_id==selected()$ids[2],c(key,"balanced","oe")]
      z <- merge(a,b,by=key,all=TRUE,suffixes=c("_reference","_comparison"))
      usable <- with(z,is.finite(oe_reference)&is.finite(oe_comparison)&oe_reference>0&oe_comparison>0)
      z$log2_oe_ratio <- NA_real_
      z$log2_oe_ratio[usable] <- log2(z$oe_comparison[usable]/z$oe_reference[usable])
      write("virtual_4C_comparison.csv",z)
    }
    metadata <- d$samples[match(selected()$ids,d$samples$sample_id),]
    metadata$role <- c("reference","comparison")
    write("sample_metadata.csv",metadata)
    write("input_gene_records.csv",d$genes)
    if(!is.null(d$phase)) write("input_phasing_track.csv",d$phase)
    if(!is.null(d$features)) write("input_regulatory_intervals.csv",d$features)
    if(d$example) file.copy(experiment_example_contacts_path,base)
    else write("input_contact_pairs.csv",d$contacts[d$contacts$sample_id%in%selected()$ids,])
    write_bed <- function(data,name) {
      if(is.null(data)) file.create(file.path(base,name))
      else write.table(data,file.path(base,name),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE,na=".")
    }
    tad <- collect("tad")
    if(!is.null(tad)) tad$size_bp <- tad$end-tad$start
    write_bed(tad,"candidate_TADs.bed")
    p <- collect("peaks")
    write("candidate_promoter_contacts.csv",p)
    if(!is.null(p)) p <- p[p$focal_candidate,]
    if(!is.null(p)) {
      widths <- p$distal_end-p$distal_start
      p <- with(p,data.frame(chromosome,promoter_start,promoter_start+widths,
        chromosome,distal_start,distal_end,paste(gene,sample_id,sep="|"),focal_enrichment))
    }
    write_bed(p,"focal_promoter_candidates.bedpe")
    if(d$example) write("MC3C_first_pair_distance.csv",mc())
    grDevices::pdf(file.path(base,"figures.pdf"),width=12,height=8)
    tryCatch({
      for(r in results[good]) {
        if(any(vapply(r$view$maps,function(m) any(m>0,na.rm=TRUE),logical(1))))
          draw_experiment(r$view,"maps",selected()$labels)
        draw_reanalysis_tracks(r,selected()$labels)
        if(!is.null(r$profiles)) for(k in unique(r$profiles$record_id)) {
          prof <- r$profiles[r$profiles$record_id==k,]
          draw_reanalysis_promoter(prof,selected()$labels)
          mtext(prof$gene[1],side=3,line=-1,outer=TRUE)
        }
      }
      if(d$example) draw_reanalysis_mc(mc())
      if(!any(good) && !d$example) { plot.new(); text(.5,.5,"No comparable region") }
    },finally=dev.off())
    config <- c(paste("Assembly",d$samples$assembly[1]),paste("Insulation window, bins",input$re_window),
      paste("R",getRversion()),paste("Shiny",packageVersion("shiny")))
    writeLines(c(config,readLines(file.path(reanalysis_root,"R/reanalysis_methods.txt"))),file.path(base,"Methods.txt"))
    file.copy(file.path(reanalysis_root,c("R/chromatin_reanalysis.R","R/experiment_visualizations.R","scripts/summarize_mc3c.awk")),base)
    archive <- file.path(dirname(path),paste0(basename(path),".zip"))
    old <- setwd(base)
    on.exit(setwd(old),add=TRUE,after=FALSE)
    utils::zip(archive,list.files("."),flags="-q")
    stopifnot(file.rename(archive,path))
  })
}
