public_cohorts_ui <- function() {
  tabPanel("Public cohorts",
    tags$section(class="card wide",
      selectInput("public_cohort","Cohort",c("TCGA-CESC · RNA expression", "CRA001401 · tissue Hi-C"))),
    conditionalPanel("input.public_cohort === 'TCGA-CESC · RNA expression'",
      tags$section(class="card wide",
        h2("TCGA-CESC primary tumours"),
        p("UCSC Xena HiSeqV2 gene expression summarized by histological group. Counts reflect samples with measured expression. Compare distributions within this cohort."),
        selectizeInput("tcga_gene","TCGA gene (search by symbol)",choices=NULL),
        plotOutput("tcga_plot",height="270px"),
        tableOutput("tcga_summary"),
        downloadButton("tcga_download","Download gene summary"),
        tags$a("UCSC Xena expression dataset",href="https://xenabrowser.net/datapages/?dataset=TCGA.CESC.sampleMap%2FHiSeqV2&host=https%3A%2F%2Ftcga.xenahubs.net"))),
    conditionalPanel("input.public_cohort === 'CRA001401 · tissue Hi-C'",
      tags$section(class="card wide",
        h2("CRA001401 cervical tissue Hi-C"),
        p("Two cervical tumour experiments and one normal cervical epithelium experiment. Labels use archive accessions. Counts and 40 kb TAD calls come from Adeel et al. (2021)."),
        tableOutput("cra_summary"),
        p(class="note","The archive provides sequencing reads. This view contains study summaries. Use the Patient cohort tab with normalized hg19 40 kb contact matrices to generate 3D structures."),
        downloadButton("cra_download","Download study summary"),
        tags$a("CRA001401 sequencing archive",href="https://ngdc.cncb.ac.cn/gsa/browse/CRA001401"), " · ",
        tags$a("Adeel et al. (2021)",href="https://doi.org/10.3389/fcell.2021.706375"))))
}

serve_public_cohorts <- function(input,output,session,tcga,cra) {
  updateSelectizeInput(session,"tcga_gene",choices=sort(unique(tcga$gene)),selected="MECOM",server=TRUE)
  distribution <- reactive({
    gene <- req(input$tcga_gene)
    tcga[tcga$gene==gene,,drop=FALSE]
  })
  output$tcga_summary <- renderTable({
    x <- distribution()
    setNames(x[c("group","n","q1","median","q3")],
             c("Histology group","Samples","25th percentile","Median","75th percentile"))
  },digits=2,striped=TRUE)
  output$tcga_plot <- renderPlot({
    x <- distribution()
    x <- x[x$n>0,]
    validate(need(nrow(x)>0,"No measured expression for this gene."))
    y <- rev(seq_len(nrow(x)))
    par(mar=c(4,13,2,1),las=1,bty="n")
    plot(x$median,y,xlim=extendrange(c(x$q1,x$q3),f=.1),ylim=c(.5,max(y)+.5),
         yaxt="n",xlab="Xena HiSeqV2 normalized expression",ylab="",pch=19,col="#146d77")
    axis(2,at=y,labels=paste0(x$group," (",x$n,")"),tick=FALSE,cex.axis=.75)
    segments(x$q1,y,x$q3,y,lwd=2,col="#146d77")
  })
  output$tcga_download <- downloadHandler(filename=function() paste0("TCGA_CESC_",input$tcga_gene,".csv"),
    content=function(file) write.csv(distribution(),file,row.names=FALSE))
  output$cra_summary <- renderTable(setNames(cra,
    c("Experiment","Tissue","Assembly","TAD resolution (kb)","Reported TADs","Reported valid reads","Sequencing runs")),
    digits=0,striped=TRUE)
  output$cra_download <- downloadHandler(filename=function() "CRA001401_tissue_HiC_summary.csv",
    content=function(file) write.csv(cra,file,row.names=FALSE))
}
