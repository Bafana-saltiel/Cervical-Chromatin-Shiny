experiment_study_measurements_path <- normalizePath("data/experiment_study_measurements.csv",mustWork=TRUE)
experiment_example_contacts_path <- normalizePath("data/experiment_example_contacts.csv.gz",mustWork=TRUE)
experiment_example_samples_path <- normalizePath("data/experiment_example_samples.csv",mustWork=TRUE)

experiment_visualizations_ui <- function() {
  tabPanel("Experiments",
    tags$section(class="card wide",
      h2("Visualize a Hi-C experiment"),
      radioButtons("experiment_source","Data",c("HeLa-S3 study example","Upload results"),inline=TRUE),
      conditionalPanel("input.experiment_source === 'HeLa-S3 study example'",
        p("GSE198610 · mitotic release · unsorted HeLa-S3 · replicate 2 · chr14 at 250 kb · GRCh38. DMSO or ICRF-193 was added at 2 h. Samples were collected at 4 h and 8 h."),
        tags$a("Study and accession records",href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE198610")),
      conditionalPanel("input.experiment_source === 'Upload results'",
        p("Upload balanced cis Hi-C contacts and sample metadata on one assembly and resolution. Start coordinates are zero-based. The upload limit is 5 MB per file. Include zero-valued pairs explicitly. Omitted pairs are treated as missing. Use one record per unordered pair. Upload only data you can share with this hosted service."),
        fileInput("experiment_contacts","Contact pairs (CSV or CSV.gz)",accept=c(".csv",".gz")),
        fileInput("experiment_samples","Sample metadata (CSV or CSV.gz)",accept=c(".csv",".gz"))),
      downloadButton("experiment_template_contacts","Download example contacts"),
      downloadButton("experiment_template_samples","Download example metadata"),
      textOutput("experiment_status")),
    tags$section(class="card wide",
      div(class="controls",
        selectInput("experiment_chr","Chromosome",choices=NULL),
        selectInput("experiment_control","Denominator / control",choices=NULL),
        selectInput("experiment_treatment","Numerator / treatment",choices=NULL)),
      textOutput("experiment_match"),
      tabsetPanel(id="experiment_plot_type",
        tabPanel("Heatmaps",value="maps",plotOutput("experiment_maps",height="420px")),
        tabPanel("Contact decay",value="decay",plotOutput("experiment_decay",height="440px")),
        tabPanel("Compartment PC1",value="pc1",plotOutput("experiment_pc1",height="350px"))),
      downloadButton("experiment_plot_download","Download current plot (PDF)"),
      downloadButton("experiment_curves_download","Download contact decay data"),
      tags$details(tags$summary("Plot definitions"),
        p("Heatmaps show log₁₀ balanced contacts on a shared scale and log₂ ratios for pairs positive in both maps. Decay curves average balanced contacts over genomic separation on the shared set of reported pairs. They include explicit zero contacts. The slope is a five-bin centred estimate of the derivative in log–log space."),
        p("Compartment PC1 is computed from correlations between observed/expected contact profiles. The second track is oriented to the first using their shared bins. Scores remain unphased, so positive and negative values do not assign A/B identity. These regional plots describe contact patterns and do not estimate chromosome entanglement or a treatment effect."))),
    tags$section(class="card wide",
      h2("Other experimental measurements"),
      radioButtons("experiment_metrics_source","Measurement data",c("HeLa-S3 study examples","Upload measurements"),inline=TRUE),
      conditionalPanel("input.experiment_metrics_source === 'HeLa-S3 study examples'",
        p("Examples from Hildebrand et al. Flow cytometry, microscopy and MC-3C values were read approximately from the published figures. Simulation values are the printed means. DMSO is the vehicle comparator. The simulation compares two initial states."),
        tags$a("Study figures",href="https://pmc.ncbi.nlm.nih.gov/articles/PMC11756355/"),
        downloadButton("experiment_study_measurements_download","Download study example CSV")),
      conditionalPanel("input.experiment_metrics_source === 'Upload measurements'",
        p("Use sample_id, metric, x and value columns. Each row is one reported measurement."),
        fileInput("experiment_metrics","Measured summaries (CSV or CSV.gz)",accept=c(".csv",".gz"))),
      selectInput("experiment_metric","Measurement",choices=NULL),
      plotOutput("experiment_metrics_plot",height="360px")))
}

read_experiment_csv <- function(file) {
  con <- if (endsWith(file$name,".gz")) gzfile(file$datapath,"rt") else base::file(file$datapath,"rt")
  on.exit(close(con))
  read.csv(con,stringsAsFactors=FALSE,colClasses=c(sample_id="character"))
}

validate_experiment <- function(contacts,samples) {
  stopifnot(
    "Missing contact columns"=all(c("sample_id","chromosome","bin1","bin2","contact") %in% names(contacts)),
    "Missing metadata columns"=all(c("sample_id","condition","time_hours","replicate","assembly") %in% names(samples)),
    "Provide at least two samples with unique IDs and one genome assembly"=
      nrow(samples)>=2L && !anyNA(samples$sample_id) && all(nzchar(samples$sample_id)) &&
      !anyDuplicated(samples$sample_id) && length(unique(samples$assembly))==1L &&
      !anyNA(samples$assembly) && all(nzchar(samples$assembly)),
    "Sample metadata requires condition, time and replicate values"=
      !anyNA(samples$condition) && all(nzchar(samples$condition)) &&
      is.numeric(samples$time_hours) && all(is.finite(samples$time_hours)) &&
      !anyNA(samples$replicate) && all(nzchar(samples$replicate)),
    "Both files must describe the same samples"=setequal(contacts$sample_id,samples$sample_id),
    "Use nonempty chromosome names"=!anyNA(contacts$chromosome) && all(nzchar(contacts$chromosome)),
    "Coordinates and contact values must be nonnegative, finite numbers"=
      all(vapply(contacts[c("bin1","bin2","contact")],function(x) is.numeric(x) && all(is.finite(x)&x>=0),logical(1))),
    "Bin coordinates must be integer positions"=all(contacts$bin1%%1==0 & contacts$bin2%%1==0))
  a <- pmin(contacts$bin1,contacts$bin2)
  contacts$bin2 <- pmax(contacts$bin1,contacts$bin2)
  contacts$bin1 <- a
  stopifnot("Repeated unordered bin pairs"=!anyDuplicated(contacts[c("sample_id","chromosome","bin1","bin2")]))
  list(contacts=contacts,samples=samples)
}

experiment_maps <- function(dataset, chr, ids) {
  d <- subset(dataset$contacts,chromosome==chr & sample_id %in% ids)
  bins <- sort(unique(c(d$bin1,d$bin2)))
  spacing <- diff(bins)
  width <- if(length(spacing)) min(spacing) else NA_real_
  validate(need(length(bins)>=5L && all(spacing%%width==0) && diff(range(bins))/width<600L,
    "Choose a chromosome region with 5–600 consecutive, equally spaced bins. Include zero pairs explicitly."))
  bins <- seq.int(min(bins),max(bins),by=width)
  build <- function(id) {
    x <- d[d$sample_id==id,]
    ij <- cbind(match(x$bin1,bins),match(x$bin2,bins))
    y <- matrix(NA_real_,length(bins),length(bins))
    y[ij] <- y[ij[,2:1,drop=FALSE]] <- x$contact
    y
  }
  maps <- lapply(ids,build)
  validate(need(any(is.finite(maps[[1]])&is.finite(maps[[2]])),
    "The two samples need reported contacts at shared coordinates."))
  list(maps=maps,bins=bins,width=width,ids=ids,chr=chr)
}

experiment_decay <- function(view) {
  a <- view$maps[[1]]; b <- view$maps[[2]]
  offset <- col(a)-row(a)
  shared <- offset>0L & is.finite(a) & is.finite(b)
  parts <- split(which(shared),offset[shared])
  validate(need(length(parts)>=2L,"At least two shared genomic separations are required."))
  s <- as.integer(names(parts))*view$width
  slope <- function(v) {
    xx <- log10(s)
    z <- ifelse(v>0,log10(v),NA_real_)
    endpoints <- seq_along(z)
    l <- pmax(1L,endpoints-2L); r <- pmin(length(z),endpoints+2L)
    (z[r]-z[l])/(xx[r]-xx[l])
  }
  do.call(rbind,lapply(seq_along(view$maps),function(i) {
    v <- vapply(parts,function(idx) mean(view$maps[[i]][idx]),numeric(1))
    data.frame(sample_id=view$ids[i],separation_bp=s,shared_pairs=lengths(parts),
               mean_balanced_contact=v,log_log_slope=slope(v))
  }))
}

experiment_pc1 <- function(view) {
  extract <- function(m) {
    offset <- abs(col(m)-row(m))
    expected <- tapply(m,offset,mean,na.rm=TRUE)
    oe <- m / as.vector(expected)[offset+1L]
    oe[offset<=1L] <- NA_real_
    keep <- rowMeans(is.finite(oe))>=.75
    if(sum(keep)<5L) return(rep(NA_real_,nrow(m)))
    x <- oe[keep,keep,drop=FALSE]
    x[!is.finite(x)] <- 1
    r <- suppressWarnings(cor(t(x)))
    r[!is.finite(r)] <- 0
    z <- rep(NA_real_,nrow(m))
    z[keep] <- eigen(r,symmetric=TRUE)$vectors[,1]
    z
  }
  x <- lapply(view$maps,extract)
  validate(need(all(vapply(x,function(z) sum(is.finite(z))>=5L,logical(1))),
    "Insufficient observed/expected coverage to estimate PC1 in both maps."))
  agreement <- suppressWarnings(cor(x[[1]],x[[2]],use="pairwise.complete.obs"))
  if(is.finite(agreement) && agreement<0) x[[2]] <- -x[[2]]
  x
}

draw_experiment <- function(view,kind,labels) {
  colors <- c("#007e88","#bf5040")
  if(kind=="maps") {
    a <- view$maps[[1]]; b <- view$maps[[2]]
    common <- is.finite(a)&is.finite(b)&a>0&b>0
    ratio <- matrix(NA_real_,nrow(a),ncol(a))
    ratio[common] <- log2(b[common])-log2(a[common])
    logs <- lapply(list(a,b),function(z) {z[z<=0] <- NA_real_; log10(z)})
    values <- unlist(logs); values <- values[is.finite(values)]
    validate(need(length(values)>0,"At least one positive contact is required."))
    contact_limits <- as.numeric(quantile(values,c(.01,.99)))
    if(diff(contact_limits)==0) contact_limits <- extendrange(contact_limits+ c(-.01,.01))
    ratio_limit <- if(any(common)) max(.1,unname(quantile(abs(ratio[common]),.99))) else 1
    par(mfrow=c(1,3),mar=c(5,4,4,1))
    pos <- view$bins/1e6
    draw_map <- function(m,title,palette,limits) {
      clipped <- pmin(pmax(m,limits[1]),limits[2])
      image(pos,pos,clipped[,ncol(clipped):1,drop=FALSE],col=palette,zlim=limits,
            xlab=paste(view$chr,"(Mb)"),ylab="Position (Mb)",yaxt="n",main=title,asp=1,cex.main=.80)
      y <- pretty(range(pos))
      axis(2,at=sum(range(pos))-y,labels=y,las=1)
      mtext(sprintf("Scale %.2f to %.2f",limits[1],limits[2]),1,line=3.5,cex=.72)
    }
    palette <- hcl.colors(80,"YlOrRd",rev=TRUE)
    draw_map(logs[[1]],labels[1],palette,contact_limits)
    draw_map(logs[[2]],labels[2],palette,contact_limits)
    draw_map(ratio,"log₂ treatment / control",hcl.colors(81,"Blue-Red 3"),c(-ratio_limit,ratio_limit))
  } else if(kind=="decay") {
    d <- experiment_decay(view)
    validate(need(any(d$mean_balanced_contact>0),"No positive shared contacts for contact decay."))
    par(mfrow=c(1,2),mar=c(5,5,3,1))
    positive <- d[d$mean_balanced_contact>0,]
    plot(positive$separation_bp,positive$mean_balanced_contact,log="xy",type="n",
         xlab="Separation (bp)",ylab="Mean balanced contact",main="Contact decay")
    for(i in seq_along(view$ids)){
      x <- d[d$sample_id==view$ids[i],]
      lines(x$separation_bp,ifelse(x$mean_balanced_contact>0,x$mean_balanced_contact,NA_real_),col=colors[i],lwd=2)
    }
    legend("topright",labels,col=colors,lty=1,bty="n",cex=.75)
    valid <- is.finite(d$log_log_slope)
    if(!any(valid)) {plot.new(); text(.5,.5,"Slope unavailable"); return(invisible(NULL))}
    plot(d$separation_bp[valid],d$log_log_slope[valid],log="x",type="n",
         xlab="Separation (bp)",ylab="d log(contact) / d log(separation)",main="Log–log slope")
    for(i in seq_along(view$ids)){
      x <- d[d$sample_id==view$ids[i],]
      lines(x$separation_bp,x$log_log_slope,col=colors[i],lwd=2)
    }
  } else {
    x <- experiment_pc1(view)
    par(mfrow=c(2,1),mar=c(4,4,2,1))
    ylim <- range(unlist(x),finite=TRUE)
    for(i in seq_along(x)){
      plot(view$bins/1e6,x[[i]],type="h",col=ifelse(x[[i]]>=0,colors[1],colors[2]),
           xlab=paste(view$chr,"(Mb)"),ylab="Unphased PC1",ylim=ylim,main=labels[i])
      abline(h=0,col="#758490")
    }
  }
}

serve_experiment_visualizations <- function(input,output,session) {
  example_contacts <- experiment_example_contacts_path
  example_samples <- experiment_example_samples_path
  output$experiment_template_contacts <- downloadHandler(
    filename=function() "GSE198610_chr14_contacts.csv.gz",
    content=function(path) file.copy(example_contacts,path))
  output$experiment_template_samples <- downloadHandler(
    filename=function() "GSE198610_sample_metadata.csv",
    content=function(path) file.copy(example_samples,path))
  dataset <- reactive({
    if(identical(input$experiment_source,"Upload results")){
      req(input$experiment_contacts,input$experiment_samples)
      tryCatch(validate_experiment(read_experiment_csv(input$experiment_contacts),
                                    read_experiment_csv(input$experiment_samples)),
               error=function(e) validate(need(FALSE,conditionMessage(e))))
    } else {
      validate_experiment(read.csv(gzfile(example_contacts)),read.csv(example_samples))
    }
  })
  sample_labels <- reactive({
    s <- dataset()$samples
    setNames(sprintf("%s · %s h · R%s (%s)",s$condition,s$time_hours,s$replicate,s$sample_id),s$sample_id)
  })
  observeEvent(dataset(),{
    d <- dataset()
    chromosomes <- sort(unique(d$contacts$chromosome))
    choices <- setNames(names(sample_labels()),sample_labels())
    updateSelectInput(session,"experiment_chr",choices=chromosomes)
    updateSelectInput(session,"experiment_control",choices=choices,selected=choices[[1]])
    updateSelectInput(session,"experiment_treatment",choices=choices,selected=choices[[2]])
  })
  output$experiment_status <- renderText({
    d <- dataset()
    sprintf("%s · %d samples · %s contact records",d$samples$assembly[1],nrow(d$samples),
            format(nrow(d$contacts),big.mark=","))
  })
  ids <- reactive({
    ids <- c(req(input$experiment_control),req(input$experiment_treatment))
    req(all(ids %in% dataset()$samples$sample_id))
    validate(need(ids[1]!=ids[2],"Select two different samples."))
    ids
  })
  view <- reactive(experiment_maps(dataset(),req(input$experiment_chr),ids()))
  captions <- reactive(unname(sample_labels()[ids()]))
  output$experiment_match <- renderText({
    s <- dataset()$samples[match(ids(),dataset()$samples$sample_id),]
    if(s$time_hours[1]!=s$time_hours[2] || s$replicate[1]!=s$replicate[2])
      "Selected samples differ in time or replicate. Interpret their contrast descriptively."
  })
  output$experiment_maps <- renderPlot(draw_experiment(view(),"maps",captions()))
  output$experiment_decay <- renderPlot(draw_experiment(view(),"decay",captions()))
  output$experiment_pc1 <- renderPlot(draw_experiment(view(),"pc1",captions()))
  output$experiment_curves_download <- downloadHandler(filename=function() "contact_decay.csv",
    content=function(path) write.csv(experiment_decay(view()),path,row.names=FALSE))
  output$experiment_plot_download <- downloadHandler(filename=function() "experiment_plot.pdf",
    content=function(path) {
      grDevices::pdf(path,width=12,height=5)
      on.exit(grDevices::dev.off())
      draw_experiment(view(),req(input$experiment_plot_type),captions())
    })
  output$experiment_study_measurements_download <- downloadHandler(
    filename=function() "HeLaS3_study_measurement_examples.csv",
    content=function(path) file.copy(experiment_study_measurements_path,path))
  metrics <- reactive({
    d <- if(identical(input$experiment_metrics_source,"Upload measurements"))
      read_experiment_csv(req(input$experiment_metrics))
    else read.csv(experiment_study_measurements_path,stringsAsFactors=FALSE)
    validate(need(all(c("sample_id","metric","x","value") %in% names(d)) &&
                    is.numeric(d$value) && all(is.finite(d$value)) &&
                    !anyNA(d[c("sample_id","metric","x")]),"Provide sample_id, metric, x and numeric value."))
    d
  })
  observeEvent(metrics(), updateSelectInput(session,"experiment_metric",choices=unique(metrics()$metric)))
  output$experiment_metrics_plot <- renderPlot({
    d <- metrics()
    d <- d[d$metric==req(input$experiment_metric),]
    req(nrow(d)>0)
    groups <- unique(d$sample_id)
    col <- hcl.colors(length(groups),"Dark 3")
    numeric_x <- suppressWarnings(as.numeric(d$x))
    if (all(is.finite(numeric_x))) d$x <- numeric_x
    if(is.numeric(d$x)){
      plot(d$x,d$value,pch=19,col=col[match(d$sample_id,groups)],xlab="Uploaded x value",ylab=input$experiment_metric)
    } else {
      levels <- unique(d$x)
      plot(match(d$x,levels),d$value,pch=19,col=col[match(d$sample_id,groups)],xaxt="n",xlab="",ylab=input$experiment_metric)
      axis(1,at=seq_along(levels),labels=levels)
    }
    legend("topright",groups,pch=19,col=col,cex=.75,bty="n")
  })
}
