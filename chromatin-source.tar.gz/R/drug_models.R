drug_comparison_samples <- function(samples) {
  samples$label <- c("HeLa-S3 DMSO","HeLa-S3 ICRF-193")
  samples$assembly <- "GRCh38"
  rbind(data.frame(model="ACH-001086",condition="HeLa reference",compound="",
                   duration_hours=NA_real_,dose="Separate study",accession="GSM6658912",
                   label="HeLa reference",assembly="GRCh38"),samples,
        data.frame(model="NHEK",condition="Non-cancerous",compound="",
                   duration_hours=NA_real_,dose="Primary skin cells",accession="GSE63525",
                   label="Normal epidermal keratinocytes",assembly="hg19"))
}

drug_models_ui <- function(samples) {
  samples <- drug_comparison_samples(samples)
  tabPanel("Drug comparison",
    tags$section(class="card wide",
      h2("HeLa, HeLa-S3 and a normal epithelial reference"),
      p("GSE198610 · asynchronous unsorted cells · replicate 2 · 2-hour HeLa-S3 exposure · 25 kb Hi-C"),
      selectizeInput("drug_gene","Drug comparison gene (search by symbol)",choices=NULL),
      actionButton("refresh_drug_structures","Refresh structures"),
      actionButton("drug_hela_reference","View gene in HeLa reference"),
      p(class="note","The drug contrast uses the matched HeLa-S3 samples. The normal reference is primary skin epithelium (NHEK), displayed at its native hg19 locus. The pairwise statistics and XAI use the three GRCh38 maps."),
      p(class="note","ICRF-193 is an experimental topoisomerase II inhibitor. The vehicle sample received DMSO. This comparison describes one replicate pair. Each geometry is fitted independently and can rotate or reflect."),
      tags$a("Study GSE198610",href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE198610")),
    tags$section(class="card wide", h2("What the main study tested"),
      p("GSE198610 followed synchronized HeLa-S3 cells from mitosis into G1 using Hi-C, multi-contact 3C and polymer simulations. The authors propose that most mitotic entanglements are removed during anaphase and telophase, with remaining entanglements removed during early G1 in a TOP2-dependent process."),
      tags$ol(
        tags$li("During decondensation, the polymer model suggests that remaining condensin loops bias TOP2 activity toward disentanglement."),
        tags$li("After loop release, lower TOP2 activity may reduce formation of new entanglements, allowing G1 chromosome territories to form.")),
      p("The maps bundled here compare asynchronous HeLa-S3 cells after two hours of exposure. The local reconstructions and explanations do not measure entanglement, resolve mitotic-exit stages or distinguish TOP2A from TOP2B inhibition."),
      tags$a("Main study and synchronized experiments",href="https://pubmed.ncbi.nlm.nih.gov/38521067/")),
    div(class="columns drug-columns",
      lapply(seq_len(nrow(samples)),function(i) {
        row <- samples[i,]
        id <- row$model
        tags$section(class="card",
          h2(row$label),
          p(class="note",paste(row$dose,"·",row$assembly,"·"),tags$a(row$accession,
            href=paste0("https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=",row$accession))),
          tags$canvas(id=paste0(id,"_canvas"),class="structure drug-structure",tabindex="0",role="img"),
          textOutput(paste0(id,"_status")),
          downloadButton(paste0(id,"_download"),"Download coordinates"))
      })),
    tags$section(class="card wide",h2("Pairwise structure and contact comparison"),
      p(class="note","Contact ranks are compared within 50–500 kb bands. 3D distance ranks compare shared bins and are independent of rotation, reflection and scale."),
      tableOutput("drug_concordance")),
    drug_explanations_ui())
}

serve_drug_models <- function(input,output,session,loci,samples,loci_hg19) {
  samples <- drug_comparison_samples(samples)
  updateSelectizeInput(session,"drug_gene",choices=loci$gene,selected="MECOM",server=TRUE)
  locus <- reactive({
    g <- req(input$drug_gene)
    x <- loci[loci$gene==g,,drop=FALSE]
    req(nrow(x)==1L)
    x
  })
  normal_locus <- reactive({
    g <- req(input$drug_gene)
    loci_hg19[loci_hg19$gene==g,,drop=FALSE]
  })
  windows <- reactive({
    input$refresh_drug_structures
    site <- locus()
    setNames(lapply(seq_len(nrow(samples)),function(i) {
      annotation <- if(samples$assembly[i]=="hg19") normal_locus() else site
      if(nrow(annotation)==1L) read_hic_window(samples$model[i],annotation)
    }),samples$model)
  })
  fits <- reactive({
    site <- locus()
    x <- windows()
    setNames(lapply(seq_len(nrow(samples)),function(i) {
      m <- samples$model[i]
      annotation <- if(samples$assembly[i]=="hg19") normal_locus() else site
      fit_hic_window(x[[m]],m,annotation)
    }),samples$model)
  })
  serve_drug_explanations(input,output,session,windows,locus,fits,samples)
  for(i in seq_len(nrow(samples))) local({
    row <- samples[i,]
    id <- row$model
    observe({
      req(input$analysis_tab=="Drug comparison")
      a <- fits()[[id]]$coordinates
      nodes <- lapply(seq_len(NROW(a)),function(j)
        list(start=a$bin_start[j],x=a$x[j],y=a$y[j],z=a$z[j],anchor=a$anchor[j]))
      session$sendCustomMessage(paste0(id,"_geometry"),list(nodes=nodes))
    })
    output[[paste0(id,"_status")]] <- renderText({
      x <- fits()[[id]]
      if(row$assembly=="hg19" && !nrow(normal_locus()))
        return("No hg19 RefSeq Select annotation for this gene.")
      if (is.null(x)) return("This locus has too few usable contacts for 3D reconstruction.")
      sprintf("%s · %s · %d bins · distance rank agreement %.2f",
              locus()$gene,x$coordinates$chr[1],nrow(x$coordinates),x$agreement)
    })
    output[[paste0(id,"_download")]] <- downloadHandler(
      filename=function() paste(input$drug_gene,row$accession,"coordinates.csv",sep="_"),
      content=function(file) {
        x <- req(fits()[[id]])$coordinates
        x$accession <- row$accession
        x$compound <- row$compound
        x$assembly <- row$assembly
        write.csv(x,file,row.names=FALSE)
      })
  })
  output$drug_concordance <- renderTable({
    x <- windows()
    f <- fits()
    pairs <- combn(which(samples$assembly=="GRCh38"),2L,simplify=FALSE)
    rows <- lapply(pairs,function(pair) {
      a <- x[[pair[1]]]; b <- x[[pair[2]]]
      if(is.null(a) || is.null(b)) return(NULL)
      ans <- compare_hic_windows(a,b,samples$label[pair])
      names(ans)[4L] <- "Contact rank correlation"
      da <- structure_distance_window(f[[pair[1]]],a$anchor)
      db <- structure_distance_window(f[[pair[2]]],b$anchor)
      shared <- intersect(da$bins,db$bins)
      ia <- match(shared,da$bins); ib <- match(shared,db$bins)
      ans[["3D distance rank correlation"]] <- if(length(shared)>=8L) {
        dist_a <- da$contacts[ia,ia,drop=FALSE]
        dist_b <- db$contacts[ib,ib,drop=FALSE]
        use <- upper.tri(dist_a) & outer(shared,shared,function(i,j) j-i)>=2L &
          outer(shared,shared,function(i,j) j-i)<=20L
        if(sum(use)>2L) suppressWarnings(cor(dist_a[use],dist_b[use],method="spearman")) else NA_real_
      } else NA_real_
      ans
    })
    validate(need(any(lengths(rows)>0),"No pairwise comparisons are available for this locus."))
    do.call(rbind,rows)
  },digits=3,striped=TRUE)
}
