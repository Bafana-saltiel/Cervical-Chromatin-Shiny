drug_models_ui <- function(samples) {
  tabPanel("Drug comparison",
    tags$section(class="card wide",
      h2("HeLa-S3 with and without ICRF-193"),
      p("GSE198610 · asynchronous unsorted cells · replicate 2 · 2-hour exposure · GRCh38 25 kb"),
      selectizeInput("drug_gene","Drug comparison gene (search by symbol)",choices=NULL),
      actionButton("refresh_drug_structures","Refresh structures"),
      actionButton("drug_hela_reference","View gene in HeLa reference"),
      p(class="note","The HeLa reference is a separate dataset. The drug contrast uses the matched HeLa-S3 samples."),
      p(class="note","ICRF-193 is an experimental topoisomerase II inhibitor. The vehicle sample received DMSO. This comparison describes one replicate pair. Each geometry is fitted independently and can rotate or reflect."),
      tags$a("Study GSE198610",href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE198610")),
    div(class="columns drug-columns",
      lapply(seq_len(nrow(samples)),function(i) {
        row <- samples[i,]
        id <- row$model
        tags$section(class="card",
          h2(paste(row$condition,"·",row$compound)),
          p(class="note",paste(row$dose,"·"),tags$a(row$accession,
            href=paste0("https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=",row$accession))),
          tags$canvas(id=paste0(id,"_canvas"),class="structure drug-structure",tabindex="0",role="img"),
          textOutput(paste0(id,"_status")),
          downloadButton(paste0(id,"_download"),"Download coordinates"))
      })),
    tags$section(class="card wide",h2("Local contact comparison"),
      p(class="note","The table compares measured contacts within 50–500 kb distance bands. It is descriptive."),
      tableOutput("drug_concordance")),
    drug_explanations_ui())
}

serve_drug_models <- function(input,output,session,loci,samples) {
  updateSelectizeInput(session,"drug_gene",choices=loci$gene,selected="MECOM",server=TRUE)
  locus <- reactive({
    g <- req(input$drug_gene)
    x <- loci[loci$gene==g,,drop=FALSE]
    req(nrow(x)==1L)
    x
  })
  windows <- reactive({
    input$refresh_drug_structures
    site <- locus()
    setNames(lapply(samples$model,read_hic_window,locus=site),samples$model)
  })
  serve_drug_explanations(input,output,session,windows,locus)
  fits <- reactive({
    site <- locus()
    x <- windows()
    setNames(lapply(samples$model,function(m) fit_hic_window(x[[m]],m,site)),samples$model)
  })
  for(i in seq_len(nrow(samples))) local({
    row <- samples[i,]
    id <- row$model
    observe({
      req(input$analysis_tab=="Drug comparison")
      a <- fits()[[id]]$coordinates
      nodes <- lapply(seq_len(NROW(a)),function(j)
        list(start=a$bin_start[j],x=a$x[j],y=a$y[j],z=a$z[j],anchor=a$anchor[j]))
      session$sendCustomMessage(paste0(id,"_geometry"),list(nodes=nodes))
    })
    output[[paste0(id,"_status")]] <- renderText({
      x <- fits()[[id]]
      if (is.null(x)) return("This locus has too few usable contacts for 3D reconstruction.")
      sprintf("%s · %s · %d bins · distance rank agreement %.2f",
              locus()$gene,locus()$chr,nrow(x$coordinates),x$agreement)
    })
    output[[paste0(id,"_download")]] <- downloadHandler(
      filename=function() paste(input$drug_gene,row$accession,"coordinates.csv",sep="_"),
      content=function(file) {
        x <- req(fits()[[id]])$coordinates
        x$accession <- row$accession
        x$compound <- row$compound
        write.csv(x,file,row.names=FALSE)
      })
  })
  output$drug_concordance <- renderTable({
    x <- windows()
    validate(need(all(vapply(x,function(w) length(w$bins)>=8L,logical(1))),
                  "Both conditions need usable contacts at this locus."))
    compare_hic_windows(x[[1]],x[[2]],samples$compound)
  },digits=3,striped=TRUE)
}
