patient_cohort_ui <- function() {
  tabPanel("Patient cohort",
    tags$section(class="card wide",
      h2("Upload cohort Hi-C contacts"),
      p("Use a CSV of normalized GRCh38 25 kb contact pairs with one row per pair per patient. Include patient_id, chr, start1, start2 and balanced. Bin starts are zero-based. The upload limit is 5 MB."),
      p(class="note","Use coded patient IDs only. Exclude names, medical record numbers and other identifying information. The file is uploaded to the hosted app for analysis in the current session."),
      downloadButton("cohort_template", "Download CSV template"),
      fileInput("cohort_file", "Cohort contacts CSV", accept=".csv"),
      textOutput("cohort_status")),
    conditionalPanel("output.cohort_ready",
      div(class="controls",
        selectizeInput("cohort_gene", "Gene (search by symbol)", choices=NULL),
        selectInput("cohort_patient", "Patient", choices=NULL)),
      tags$section(class="card",
        div(class="cardhead", uiOutput("cohort_locus"),
          conditionalPanel("output.cohort_has_structure", actionButton("cohort_reset", "Reset view"))),
        conditionalPanel("output.cohort_has_structure",
          tags$canvas(id="cohort_structure", class="structure", tabindex="0", role="img"),
          p(class="note","Drag or use arrow keys to rotate. Red marks the promoter bin."),
          downloadButton("cohort_coordinates","Download patient coordinates")),
        conditionalPanel("!output.cohort_has_structure",
          p(class="note","This patient has too few usable contacts at the selected locus for a 3D reconstruction."))),
      tags$section(class="card wide",
        h2("Cohort coverage at selected locus"),
        p(class="note","Each patient is fitted independently. Fit scores describe geometry agreement and do not measure a clinical outcome."),
        tableOutput("cohort_summary"), downloadButton("cohort_summary_csv", "Download cohort summary"))))
}

read_cohort_contacts <- function(path) {
  x <- read.csv(path, colClasses=c(patient_id="character"), stringsAsFactors=FALSE)
  validate_contact_columns(x)
  if (!nrow(x) || !("patient_id" %in% names(x)) ||
      any(is.na(x$patient_id) | !grepl("^[A-Za-z0-9_-]{1,50}$", x$patient_id)))
    stop("Include coded patient IDs of 1–50 letters, numbers, hyphens or underscores.")
  if (any(is.na(x$chr) | !x$chr %in% paste0("chr", c(1:22, "X", "Y"))))
    stop("Use primary chromosome names such as chr1 or chrX.")
  if (any(!is.finite(x$balanced) | x$balanced < 0))
    stop("Balanced contacts must be finite, nonnegative numbers.")
  pairs <- data.frame(patient=x$patient_id, chr=x$chr,
                      left=pmin(x$start1,x$start2), right=pmax(x$start1,x$start2))
  if (anyDuplicated(pairs)) stop("Provide only one record per bin pair per patient.")
  split(x[c("chr","start1","start2","balanced")], x$patient_id)
}

serve_patient_cohort <- function(input, output, session, loci) {
  cohort <- reactive({
    req(input$cohort_file)
    tryCatch(read_cohort_contacts(input$cohort_file$datapath),
             error=function(e) structure(list(message=conditionMessage(e)), class="cohort_error"))
  })
  output$cohort_ready <- reactive(!inherits(cohort(), "cohort_error"))
  outputOptions(output,"cohort_ready",suspendWhenHidden=FALSE)
  output$cohort_status <- renderText({
    x <- cohort()
    if (inherits(x,"cohort_error")) x$message else
      sprintf("Loaded %d patients and %s contact pairs.", length(x), format(sum(vapply(x, nrow, integer(1))),big.mark=","))
  })
  updateSelectizeInput(session,"cohort_gene",choices=loci$gene,selected="MECOM",server=TRUE)
  observeEvent(cohort(), {
    x <- cohort()
    if (!inherits(x,"cohort_error")) updateSelectInput(session,"cohort_patient",choices=names(x))
  })
  cohort_locus <- reactive({
    req(input$cohort_gene)
    x <- loci[loci$gene == input$cohort_gene,,drop=FALSE]
    req(nrow(x) == 1)
    x
  })
  windows <- reactive({
    x <- cohort()
    req(!inherits(x,"cohort_error"))
    locus <- cohort_locus()
    lapply(x, fit_uploaded_contacts, locus=locus)
  })
  fits <- reactive({
    x <- windows()
    setNames(lapply(names(x), function(id) fit_hic_window(x[[id]], id, cohort_locus())), names(x))
  })
  current_fit <- reactive(fits()[[req(input$cohort_patient)]])
  output$cohort_has_structure <- reactive(!is.null(current_fit()))
  outputOptions(output,"cohort_has_structure",suspendWhenHidden=FALSE)
  observe({
    a <- current_fit()$coordinates
    nodes <- lapply(seq_len(NROW(a)), function(i)
      list(start=a$bin_start[i],x=a$x[i],y=a$y[i],z=a$z[i],anchor=a$anchor[i]))
    session$sendCustomMessage("cohort_geometry",list(nodes=nodes))
  })
  observeEvent(input$cohort_reset,session$sendCustomMessage("cohort_reset_geometry",list()))
  output$cohort_locus <- renderUI({
    site <- cohort_locus()
    tagList(h2(paste(site$gene, "·", req(input$cohort_patient))),
            p(class="note", paste(site$chr, format(site$tss0,big.mark=","), "·", site$transcript)))
  })
  summary_table <- reactive({
    x <- windows()
    fitted <- fits()
    data.frame(patient_id=names(x), gene=cohort_locus()$gene,
      bins=vapply(x,function(z) length(z$bins),integer(1)),
      positive_bin_pairs=vapply(x,function(z)
        if (is.null(z)) 0L else sum(upper.tri(z$contacts) & z$contacts>0),integer(1)),
      reconstruction=ifelse(vapply(fitted,is.null,logical(1)),"Unavailable","Available"),
      distance_rank_agreement=vapply(fitted,function(z) if (is.null(z)) NA_real_ else z$agreement, numeric(1)),
      eigenvalue_fraction=vapply(fitted,function(z) if (is.null(z)) NA_real_ else z$fraction, numeric(1)))
  })
  output$cohort_summary <- renderTable(summary_table(), digits=3, na="—", striped=TRUE, width="100%")
  output$cohort_template <- downloadHandler(filename=function() "patient_hic_cohort_template.csv",
    content=function(file) writeLines("patient_id,chr,start1,start2,balanced",file))
  output$cohort_coordinates <- downloadHandler(filename=function()
    paste(input$cohort_patient,input$cohort_gene,"coordinates.csv",sep="_"),
    content=function(file) {
      a <- req(current_fit())$coordinates
      names(a)[names(a)=="model"] <- "patient_id"
      a$reference_transcript <- cohort_locus()$transcript
      write.csv(a,file,row.names=FALSE)
    })
  output$cohort_summary_csv <- downloadHandler(filename=function() paste0(input$cohort_gene,"_cohort_summary.csv"),
    content=function(file) write.csv(summary_table(),file,row.names=FALSE))
}
