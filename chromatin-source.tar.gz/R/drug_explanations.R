drug_explanations_ui <- function() {
  tags$section(class="card wide",
    h2("Explain differences across structures and contacts"),
    p("Select the contrast, outcome and bin pair. Positive log₂ ratios indicate larger median-scaled values in the first named sample."),
    div(class="controls",
      selectInput("drug_explain_contrast","Comparison",
        choices=c("HeLa-S3 ICRF-193 ÷ DMSO (matched)"="3:2",
                  "HeLa-S3 DMSO ÷ HeLa reference"="2:1",
                  "HeLa-S3 ICRF-193 ÷ HeLa reference"="3:1")),
      selectInput("drug_explain_outcome","Explain",c("3D distance","Contact strength"))),
    selectizeInput("drug_explain_pair","Genomic bin pair",choices=NULL),
    textOutput("drug_explain_fit"),
    div(class="columns drug-columns",
      div(h3("SHAP contributions"), plotOutput("drug_shap",height="190px"),
          textOutput("drug_shap_baseline")),
      div(h3("LIME local contributions"), plotOutput("drug_lime",height="190px"),
          textOutput("drug_lime_fidelity"))),
    tableOutput("drug_explain_difference"),
    h3("What this means"),
    uiOutput("drug_explain_interpretation"),
    downloadButton("drug_explain_download","Download explanation"),
    tags$details(tags$summary("Model and interpretation"),
      p("The quadratic model uses genomic separation and midpoint offset from the promoter. It fits the log₂ ratio of either inferred 3D distances or balanced Hi-C contacts. Values are median-scaled within each sample across shared positive bin pairs 50–500 kb apart. Zero and missing values are excluded."),
      p("SHAP averages predictions over the empirical background of eligible pairs. LIME uses a locally weighted linear surrogate on observed feature combinations. Its baseline is the surrogate prediction at the weighted neighborhood mean. Both contributions use log₂-ratio units. The difference is LIME minus SHAP and reflects both the local approximation and the different baselines. Weighted R² describes how closely LIME matches the model in that neighborhood."),
      p("The matched drug comparison uses one replicate pair. The HeLa reference comes from a different study and subline. Cross-study differences may reflect the cell line, protocol, or condition. The explanations describe fitted associations."),
      tags$a("SHAP method", href="https://arxiv.org/abs/1705.07874"), " · ",
      tags$a("LIME method", href="https://arxiv.org/abs/1602.04938")))
}

fit_drug_contrast <- function(control, treated) {
  if (is.null(control) || is.null(treated)) return(NULL)
  bins <- intersect(control$bins, treated$bins)
  a <- match(bins,control$bins)
  b <- match(bins,treated$bins)
  x <- control$contacts[a,a,drop=FALSE]
  y <- treated$contacts[b,b,drop=FALSE]
  gaps <- outer(bins,bins,function(i,j) j-i)
  pairs <- which(gaps>=2L & gaps<=20L & x>0 & y>0 & is.finite(x) & is.finite(y),
                 arr.ind=TRUE)
  if(nrow(pairs)<20L) return(NULL)
  left <- bins[pairs[,1]]
  right <- bins[pairs[,2]]
  feature <- data.frame(separation=(right-left)*25, midpoint=((left+right)/2-control$anchor)*25)
  spread <- vapply(feature,sd,numeric(1))
  if(any(spread<=0)) return(NULL)
  standardized <- as.data.frame(scale(feature))
  observed <- log2(y[pairs]/median(y[pairs]))-log2(x[pairs]/median(x[pairs]))
  fit <- lm(observed ~ separation + midpoint + I(separation^2) + I(midpoint^2) +
              separation:midpoint, data=standardized)
  if(fit$rank<6L) return(NULL)
  list(fit=fit, inputs=standardized, feature=feature, observed=observed, predicted=fitted(fit),
       left=left*25000L, right=right*25000L)
}

explain_drug_pair <- function(model,index) {
  background <- model$inputs
  point <- background[index,,drop=FALSE]
  predicted <- unname(model$predicted[index])
  baseline <- mean(model$predicted)
  separation <- mean(predict(model$fit, transform(background, separation=point$separation)))
  midpoint <- mean(predict(model$fit, transform(background, midpoint=point$midpoint)))
  shap <- c((separation-baseline+predicted-midpoint)/2,
            (midpoint-baseline+predicted-separation)/2)
  centered <- transform(background, separation=separation-point$separation,
                        midpoint=midpoint-point$midpoint)
  weight <- exp(-rowSums(centered^2)/(.75^2))
  target <- model$predicted
  local <- lm(target ~ separation + midpoint, data=centered, weights=weight)
  spread <- sum(weight*(target-weighted.mean(target,weight))^2)
  slopes <- unname(coef(local)[-1L])
  means <- vapply(centered, weighted.mean, numeric(1), w=weight)
  lime <- -means*slopes
  lime_prediction <- unname(coef(local)[1L])
  lime_baseline <- lime_prediction-sum(lime)
  list(shap=shap, baseline=baseline, predicted=predicted, observed=model$observed[index],
       slopes=slopes, lime=unname(lime), lime_baseline=lime_baseline,
       lime_prediction=lime_prediction,
       fidelity=if(spread>0) 1-sum(weight*residuals(local)^2)/spread else NA_real_)
}

structure_distance_window <- function(fit,anchor) {
  if(is.null(fit)) return(NULL)
  z <- fit$coordinates
  list(bins=z$bin_start%/%25000L,anchor=anchor,
       contacts=as.matrix(dist(z[c("x","y","z")])))
}

serve_drug_explanations <- function(input,output,session,windows,locus,fits,samples) {
  comparison <- reactive({
    as.integer(strsplit(req(input$drug_explain_contrast),":",fixed=TRUE)[[1]])
  })
  fit <- reactive({
    x <- windows()
    ids <- comparison()
    if(identical(input$drug_explain_outcome,"3D distance")) {
      f <- fits()
      x <- lapply(ids,function(i) structure_distance_window(f[[i]],x[[i]]$anchor))
      return(fit_drug_contrast(x[[2]],x[[1]]))
    }
    fit_drug_contrast(x[[ids[2]]],x[[ids[1]]])
  })
  observeEvent(fit(), {
    x <- fit()
    if(is.null(x)) {
      updateSelectizeInput(session,"drug_explain_pair",choices=character(),server=TRUE)
    } else {
      labels <- sprintf("%s:%s – %s (%d kb)",locus()$chr,
        format(x$left,big.mark=",",trim=TRUE),format(x$right,big.mark=",",trim=TRUE),
        x$feature$separation)
      updateSelectizeInput(session,"drug_explain_pair",
        choices=setNames(seq_along(labels),labels),
        selected=which.min(abs(x$feature$midpoint)),server=TRUE)
    }
  },ignoreNULL=FALSE)
  explanation <- reactive({
    x <- fit()
    validate(need(!is.null(x),"Too few usable shared bin pairs to fit an explanation at this locus."))
    i <- suppressWarnings(as.integer(input$drug_explain_pair))
    req(length(i)==1L,!is.na(i),i>=1L,i<=length(x$observed))
    explain_drug_pair(x,i)
  })
  labels <- c("Genomic separation","Midpoint offset")
  draw <- function(value,other) {
    validate(need(all(is.finite(value)),"This explanation is unavailable for the selected pair."))
    par(mar=c(4,10,1,1),las=1,bty="n")
    lim <- max(abs(c(value,other,.01)),na.rm=TRUE)
    barplot(rev(value),names.arg=rev(labels),horiz=TRUE,
      col=ifelse(rev(value)>=0,"#146d77","#a64c36"),border=NA,
      xlim=c(-lim,lim)*1.1,xlab="Contribution to fitted log₂ ratio",cex.names=.82)
    abline(v=0,col="#263c47")
  }
  output$drug_explain_fit <- renderText({
    x <- explanation()
    sprintf("Observed log₂ ratio %.3f · fitted log₂ ratio %.3f · %d shared positive bin pairs",
            x$observed,x$predicted,length(fit()$observed))
  })
  output$drug_shap <- renderPlot({
    x <- explanation()
    draw(x$shap,x$lime)
  })
  output$drug_shap_baseline <- renderText(sprintf("SHAP baseline %.3f",explanation()$baseline))
  output$drug_lime <- renderPlot({
    x <- explanation()
    draw(x$lime,x$shap)
  })
  output$drug_lime_fidelity <- renderText({
    x <- explanation()
    sprintf("LIME baseline %.3f · surrogate prediction %.3f · weighted R² %s",
      x$lime_baseline,x$lime_prediction,if(is.finite(x$fidelity)) sprintf("%.3f",x$fidelity) else "unavailable")
  })
  output$drug_explain_difference <- renderTable({
    x <- explanation()
    data.frame(Feature=labels, SHAP=x$shap, LIME=x$lime,
               "LIME − SHAP"=x$lime-x$shap, check.names=FALSE)
  },digits=3,striped=TRUE)
  output$drug_explain_interpretation <- renderUI({
    x <- explanation()
    ids <- comparison()
    metric <- if (identical(input$drug_explain_outcome,"3D distance"))
      "median-scaled inferred 3D distance" else "median-scaled balanced Hi-C contact strength"
    describe_ratio <- function(log_ratio) {
      change <- 100*expm1(log(2)*log_ratio)
      if (abs(change)<.05) "within 0.05% of the denominator" else
        sprintf("%.1f%% %s than the denominator",abs(change),if(change>0) "higher" else "lower")
    }
    tagList(
      p(sprintf("At the selected %s bin pair, %s has %s %s. The fitted model estimates %s.",
        locus()$gene,samples$label[ids[1]],metric,describe_ratio(x$observed),describe_ratio(x$predicted))),
      p(sprintf("SHAP starts at the average fitted log₂ ratio (%.3f). Genomic separation contributes %+.3f and midpoint offset contributes %+.3f to reach the fitted value (%.3f).",
        x$baseline,x$shap[1],x$shap[2],x$predicted)),
      if (all(is.finite(x$lime))) p(sprintf("LIME starts at its local baseline (%.3f). Genomic separation contributes %+.3f and midpoint offset contributes %+.3f to reach the local approximation (%.3f).",
        x$lime_baseline,x$lime[1],x$lime[2],x$lime_prediction)),
      if (is.finite(x$fidelity)) p(sprintf("LIME’s local weighted R² is %.3f. This measures agreement with the fitted model near this bin pair. It does not measure agreement with the experimental data or establish a drug effect.",x$fidelity)),
      p(class="note",if (1L %in% ids)
        "The HeLa map is a related reference from a separate study. Differences can reflect the subline, study protocol, or experimental condition."
        else "This is the matched HeLa-S3 drug-versus-vehicle comparison. The separate HeLa reference does not enter this fit. One matched replicate pair supports descriptive comparison."))
  })
  output$drug_explain_download <- downloadHandler(filename=function()
    paste0(locus()$gene,"_HeLa_structure_explanation.csv"),content=function(file) {
    x <- explanation()
    m <- fit()
    i <- as.integer(input$drug_explain_pair)
    ids <- comparison()
    write.csv(data.frame(gene=locus()$gene,chromosome=locus()$chr,
      numerator=samples$accession[ids[1]],denominator=samples$accession[ids[2]],
      outcome=input$drug_explain_outcome,
      left=m$left[i],right=m$right[i],feature=labels,
      observed_log2_ratio=x$observed,fitted_log2_ratio=x$predicted,
      shap_baseline=x$baseline,shap_contribution=x$shap,
      lime_baseline=x$lime_baseline,lime_prediction=x$lime_prediction,
      lime_contribution=x$lime,lime_minus_shap=x$lime-x$shap,
      lime_slope_per_sd=x$slopes,lime_weighted_r2=x$fidelity),file,row.names=FALSE)
  })
}
