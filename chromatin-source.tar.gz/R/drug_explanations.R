drug_explanations_ui <- function() {
  tags$section(class="card wide",
    h2("Explain local contact differences"),
    p("Select a bin pair to explain the fitted log₂ contact ratio. Positive values indicate greater median-scaled contact strength in the ICRF-193 map."),
    selectizeInput("drug_explain_pair","Genomic bin pair",choices=NULL),
    textOutput("drug_explain_fit"),
    div(class="columns drug-columns",
      div(h3("SHAP contributions"), plotOutput("drug_shap",height="190px"),
          textOutput("drug_shap_baseline")),
      div(h3("LIME local contributions"), plotOutput("drug_lime",height="190px"),
          textOutput("drug_lime_fidelity"))),
    tableOutput("drug_explain_difference"),
    downloadButton("drug_explain_download","Download explanation"),
    tags$details(tags$summary("Model and interpretation"),
      p("The quadratic model uses genomic separation and midpoint offset from the promoter. Its target is the log₂ ratio of the two balanced contact values after dividing each map by its median across shared positive contacts 50–500 kb apart. The model excludes zero or missing contacts and fits the remaining pairs at the selected locus."),
      p("SHAP averages predictions over the empirical background of eligible pairs. LIME uses a locally weighted linear surrogate on observed feature combinations. Its baseline is the surrogate prediction at the weighted neighborhood mean. Both contributions use log₂-ratio units. The difference is LIME minus SHAP and reflects both the local approximation and the different baselines. Weighted R² describes how closely LIME matches the model in that neighborhood."),
      p("The Hi-C maps are from one matched replicate pair. These explanations describe a fitted model of measured contacts. Bin pairs share genomic bins and do not provide independent treatment replicates."),
      tags$a("SHAP method", href="https://arxiv.org/abs/1705.07874"), " · ",
      tags$a("LIME method", href="https://arxiv.org/abs/1602.04938")))
}

fit_drug_contrast <- function(control, treated) {
  if (is.null(control) || is.null(treated)) return(NULL)
  bins <- intersect(control$bins, treated$bins)
  a <- match(bins,control$bins)
  b <- match(bins,treated$bins)
  x <- control$contacts[a,a,drop=FALSE]
  y <- treated$contacts[b,b,drop=FALSE]
  gaps <- outer(bins,bins,function(i,j) j-i)
  pairs <- which(gaps>=2L & gaps<=20L & x>0 & y>0 & is.finite(x) & is.finite(y),
                 arr.ind=TRUE)
  if(nrow(pairs)<20L) return(NULL)
  left <- bins[pairs[,1]]
  right <- bins[pairs[,2]]
  feature <- data.frame(separation=(right-left)*25, midpoint=((left+right)/2-control$anchor)*25)
  spread <- vapply(feature,sd,numeric(1))
  if(any(spread<=0)) return(NULL)
  standardized <- as.data.frame(scale(feature))
  observed <- log2(y[pairs]/median(y[pairs]))-log2(x[pairs]/median(x[pairs]))
  fit <- lm(observed ~ separation + midpoint + I(separation^2) + I(midpoint^2) +
              separation:midpoint, data=standardized)
  if(fit$rank<6L) return(NULL)
  list(fit=fit, inputs=standardized, feature=feature, observed=observed, predicted=fitted(fit),
       left=left*25000L, right=right*25000L)
}

explain_drug_pair <- function(model,index) {
  background <- model$inputs
  point <- background[index,,drop=FALSE]
  predicted <- unname(model$predicted[index])
  baseline <- mean(model$predicted)
  separation <- mean(predict(model$fit, transform(background, separation=point$separation)))
  midpoint <- mean(predict(model$fit, transform(background, midpoint=point$midpoint)))
  shap <- c((separation-baseline+predicted-midpoint)/2,
            (midpoint-baseline+predicted-separation)/2)
  centered <- transform(background, separation=separation-point$separation,
                        midpoint=midpoint-point$midpoint)
  weight <- exp(-rowSums(centered^2)/(.75^2))
  target <- model$predicted
  local <- lm(target ~ separation + midpoint, data=centered, weights=weight)
  spread <- sum(weight*(target-weighted.mean(target,weight))^2)
  slopes <- unname(coef(local)[-1L])
  means <- vapply(centered, weighted.mean, numeric(1), w=weight)
  lime <- -means*slopes
  lime_prediction <- unname(coef(local)[1L])
  lime_baseline <- lime_prediction-sum(lime)
  list(shap=shap, baseline=baseline, predicted=predicted, observed=model$observed[index],
       slopes=slopes, lime=unname(lime), lime_baseline=lime_baseline,
       lime_prediction=lime_prediction,
       fidelity=if(spread>0) 1-sum(weight*residuals(local)^2)/spread else NA_real_)
}

serve_drug_explanations <- function(input,output,session,windows,locus) {
  fit <- reactive({
    x <- windows()
    fit_drug_contrast(x[[1]],x[[2]])
  })
  observeEvent(fit(), {
    x <- fit()
    if(is.null(x)) {
      updateSelectizeInput(session,"drug_explain_pair",choices=character(),server=TRUE)
    } else {
      labels <- sprintf("%s:%s – %s (%d kb)",locus()$chr,
        format(x$left,big.mark=",",trim=TRUE),format(x$right,big.mark=",",trim=TRUE),
        x$feature$separation)
      updateSelectizeInput(session,"drug_explain_pair",
        choices=setNames(seq_along(labels),labels),
        selected=which.min(abs(x$feature$midpoint)),server=TRUE)
    }
  },ignoreNULL=FALSE)
  explanation <- reactive({
    x <- fit()
    validate(need(!is.null(x),"Too few usable shared contacts to fit an explanation at this locus."))
    i <- suppressWarnings(as.integer(input$drug_explain_pair))
    req(length(i)==1L,!is.na(i),i>=1L,i<=length(x$observed))
    explain_drug_pair(x,i)
  })
  labels <- c("Genomic separation","Midpoint offset")
  draw <- function(value,other) {
    validate(need(all(is.finite(value)),"This explanation is unavailable for the selected pair."))
    par(mar=c(4,10,1,1),las=1,bty="n")
    lim <- max(abs(c(value,other,.01)),na.rm=TRUE)
    barplot(rev(value),names.arg=rev(labels),horiz=TRUE,
      col=ifelse(rev(value)>=0,"#146d77","#a64c36"),border=NA,
      xlim=c(-lim,lim)*1.1,xlab="Contribution to fitted log₂ ratio",cex.names=.82)
    abline(v=0,col="#263c47")
  }
  output$drug_explain_fit <- renderText({
    x <- explanation()
    sprintf("Observed log₂ ratio %.3f · fitted log₂ ratio %.3f · %d shared positive pairs",
            x$observed,x$predicted,length(fit()$observed))
  })
  output$drug_shap <- renderPlot({
    x <- explanation()
    draw(x$shap,x$lime)
  })
  output$drug_shap_baseline <- renderText(sprintf("SHAP baseline %.3f",explanation()$baseline))
  output$drug_lime <- renderPlot({
    x <- explanation()
    draw(x$lime,x$shap)
  })
  output$drug_lime_fidelity <- renderText({
    x <- explanation()
    sprintf("LIME baseline %.3f · surrogate prediction %.3f · weighted R² %s",
      x$lime_baseline,x$lime_prediction,if(is.finite(x$fidelity)) sprintf("%.3f",x$fidelity) else "unavailable")
  })
  output$drug_explain_difference <- renderTable({
    x <- explanation()
    data.frame(Feature=labels, SHAP=x$shap, LIME=x$lime,
               "LIME − SHAP"=x$lime-x$shap, check.names=FALSE)
  },digits=3,striped=TRUE)
  output$drug_explain_download <- downloadHandler(filename=function()
    paste0(locus()$gene,"_HeLaS3_contact_explanation.csv"),content=function(file) {
    x <- explanation()
    m <- fit()
    i <- as.integer(input$drug_explain_pair)
    write.csv(data.frame(gene=locus()$gene,chromosome=locus()$chr,
      left=m$left[i],right=m$right[i],feature=labels,
      observed_log2_ratio=x$observed,fitted_log2_ratio=x$predicted,
      shap_baseline=x$baseline,shap_contribution=x$shap,
      lime_baseline=x$lime_baseline,lime_prediction=x$lime_prediction,
      lime_contribution=x$lime,lime_minus_shap=x$lime-x$shap,
      lime_slope_per_sd=x$slopes,lime_weighted_r2=x$fidelity),file,row.names=FALSE)
  })
}
