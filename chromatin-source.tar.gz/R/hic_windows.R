hic_bin_size <- 25000L
hic_flank_bins <- 20L

read_hic_window <- function(model, locus) {
  path <- file.path(hic_directory, model, paste0(locus$chr, ".bin.gz"))
  if (!file.exists(path)) return(NULL)
  con <- gzfile(path, "rb")
  on.exit(close(con))
  n <- readBin(con, integer(), 1L, endian = "little")
  offsets <- 2L * hic_flank_bins + 1L
  band <- matrix(readBin(con, numeric(), n * offsets, size = 4L, endian = "little"),
                 nrow = offsets)
  anchor <- locus$tss0 %/% hic_bin_size
  if (anchor >= n) return(NULL)
  bins <- seq.int(max(0L, anchor - hic_flank_bins), min(n - 1L, anchor + hic_flank_bins))
  left <- outer(bins, bins, pmin)
  delta <- abs(outer(bins, bins, "-"))
  contacts <- matrix(band[cbind(as.vector(delta) + 1L, as.vector(left) + 1L)],
                     nrow = length(bins))
  keep <- rowSums(contacts > 0) > 0
  list(bins = bins[keep], anchor = anchor, contacts = contacts[keep, keep, drop = FALSE])
}

fit_hic_window <- function(x, model, locus) {
  if (is.null(x) || length(x$bins) < 8L || !x$anchor %in% x$bins) return(NULL)
  contacts <- x$contacts
  use <- upper.tri(contacts) & contacts > 0
  if (sum(use) < 8L) return(NULL)
  positive <- contacts[use]
  scaled <- pmax(contacts, as.numeric(quantile(positive, .1))) / median(positive)
  distance <- scaled^(-1/3)
  diag(distance) <- 0
  fit <- suppressWarnings(cmdscale(as.dist(distance), k = 3L, eig = TRUE))
  if (ncol(fit$points) != 3L || any(!is.finite(fit$points))) return(NULL)
  xyz <- fit$points
  coordinates <- data.frame(model = model, gene = locus$gene, chr = locus$chr,
    bin_start = x$bins * if (is.null(x$bin_size)) hic_bin_size else x$bin_size, anchor = x$bins == x$anchor,
    x = xyz[,1], y = xyz[,2], z = xyz[,3])
  rho <- suppressWarnings(cor(distance[use], as.matrix(dist(xyz))[use], method = "spearman"))
  list(coordinates = coordinates, agreement = rho, fraction = fit$GOF[1])
}

compare_hic_windows <- function(x, y, labels) {
  common <- intersect(x$bins, y$bins)
  ix <- match(common, x$bins)
  iy <- match(common, y$bins)
  a <- x$contacts[ix, ix, drop = FALSE]
  b <- y$contacts[iy, iy, drop = FALSE]
  delta <- outer(common, common, function(i, j) j - i)
  bands <- lapply(2:20, function(d) which(delta == d))
  bands <- Filter(function(idx) length(idx) >= 5L &&
    length(unique(a[idx])) > 1L && length(unique(b[idx])) > 1L, bands)
  ranks <- function(values) unlist(lapply(bands, function(i)
    (rank(values[i], ties.method = "average") - .5) / length(i)), use.names = FALSE)
  ra <- ranks(a)
  rb <- ranks(b)
  data.frame(First = labels[1], Second = labels[2], "Shared bin pairs" = length(ra),
             "Rank correlation" = if (length(ra) >= 10L) cor(ra, rb) else NA_real_,
             check.names = FALSE)
}

read_uploaded_window <- function(path, locus) {
  x <- read.csv(path, stringsAsFactors = FALSE)
  validate_contact_columns(x)
  fit_uploaded_contacts(x, locus, require_contacts = TRUE)
}

validate_contact_columns <- function(x, bin_size=hic_bin_size) {
  required <- c("chr", "start1", "start2", "balanced")
  if (!all(required %in% names(x))) stop("CSV needs chr, start1, start2 and balanced columns.")
  if (!all(vapply(x[required[-1]], is.numeric, logical(1)))) stop("Bin starts and balanced contacts must be numeric.")
  ends <- c(x$start1, x$start2)
  if (any(!is.finite(ends) | ends < 0 | ends %% bin_size != 0))
    stop("Use zero-based coordinates aligned to the selected bin size.", call. = FALSE)
}

fit_uploaded_contacts <- function(x, locus, require_contacts = FALSE, bin_size=hic_bin_size) {
  x <- x[which(x$chr == locus$chr), , drop = FALSE]
  anchor <- locus$tss0 %/% bin_size
  flank <- 500000L %/% bin_size
  lo <- (anchor - flank) * bin_size
  hi <- (anchor + flank) * bin_size
  x <- subset(x, start1 >= lo & start1 <= hi & start2 >= lo & start2 <= hi &
                   is.finite(balanced) & balanced > 0)
  if (!nrow(x)) {
    if (require_contacts) stop("No positive normalized contacts are available in this locus window.")
    return(NULL)
  }
  pairs <- cbind(pmin(x$start1, x$start2), pmax(x$start1, x$start2))
  if (anyDuplicated(pairs)) stop("Provide only one record per bin pair.")
  bins <- sort(unique(c(x$start1, x$start2)))
  z <- matrix(0, length(bins), length(bins))
  i <- match(x$start1, bins)
  j <- match(x$start2, bins)
  z[cbind(i, j)] <- z[cbind(j, i)] <- x$balanced
  list(bins = bins %/% bin_size, anchor = anchor, contacts = z, bin_size = bin_size)
}
