library(shiny)
xyz <- read.csv("data/Review_3D_coordinates.csv")
qc <- read.csv("data/Review_3D_diagnostics.csv")
rho <- read.csv("data/review_contact_concordance.csv")
models <- read.csv("data/depmap_models.csv")
dep <- read.csv("data/depmap_values.csv")
panels <- read.delim("data/review_panels.tsv")
genes <- sort(unique(xyz$gene))
stopifnot(length(genes)==61, nrow(qc)==183, nrow(dep)==366)
label <- function(ids) models$CellLineName[match(ids,models$model)]

ui <- fluidPage(
  tags$head(tags$link(rel="stylesheet",href=paste0(getOption("chromatin.assetPrefix", ""), "app.css")),tags$script(src=paste0(getOption("chromatin.assetPrefix", ""), "structure.js"))),
  tags$header(tags$div(class="frame",h1("Cervical cancer chromatin explorer"),
                      p("Explore inferred 3D Hi-C structures and matched DepMap measurements."))),
  tags$main(class="frame",
    div(class="controls",selectInput("panel","Research panel",c("All loci",panels$project)),
        selectInput("gene","Gene",genes,selected="MECOM"),
        selectInput("model","Cell line",setNames(models$model,models$CellLineName),selected="SiHa")),
    div(class="columns",
      tags$section(class="card",
        div(class="cardhead",uiOutput("locus"),actionButton("reset","Reset view")),
        tags$canvas(id="structure",tabindex="0",role="img"),
        p(class="note","Drag or use arrow keys to rotate. Scroll or use +/− to zoom. Red marks the promoter bin."),
        textOutput("quality"),br(),downloadButton("coords","Download coordinates")),
      tags$section(class="card",h2("DepMap context"),uiOutput("dep_id"),
        uiOutput("metrics"),plotOutput("comparison",height="235px"),
        p(class="note","More negative CRISPR scores indicate stronger loss of viability after knockout. Unavailable measurements are left missing."),
        downloadButton("depmap","Download gene data"))),
    tags$section(class="card wide",h2("Local Hi-C concordance"),
        p(class="note","Rank correlations within distance bands from 50 to 500 kb."),
        tableOutput("concordance")),
    tags$details(class="card wide",tags$summary("Sources and interpretation"),
      p("The three SCC maps use 25 kb GRCh38 cis contacts from GEO GSE195631. Coordinates are independently fitted from population-averaged Hi-C using classical multidimensional scaling. Distances and orientations are arbitrary."),
      p("DepMap Public 24Q4 assays were joined by verified ACH model IDs and gene symbols. These assays are independent of the Hi-C measurements. The app supports hypothesis generation about cell lines."),
      tags$a("GEO GSE195631",href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE195631")," · ",
      tags$a("DepMap Public 24Q4",href="https://doi.org/10.25452/figshare.plus.27993248.v1"))
  )
)

server <- function(input,output,session){
  observeEvent(input$panel,{
    choices <- if(input$panel=="All loci") genes else
      sort(strsplit(panels$genes[match(input$panel,panels$project)]," ",fixed=TRUE)[[1]])
    previous <- isolate(input$gene)
    updateSelectInput(session,"gene",choices=choices,selected=if(previous %in% choices) previous else choices[1])
  },ignoreInit=TRUE)
  geometry <- reactive({
    req(input$model,input$gene)
    x <- xyz[xyz$model==input$model & xyz$gene==input$gene,]
    validate(need(nrow(x)>0,"Geometry unavailable"))
    x[order(x$bin_start),]
  })
  gene_data <- reactive({
    req(input$gene)
    d <- dep[dep$gene==input$gene,]
    d$ModelID <- models$ModelID[match(d$model,models$model)]
    d
  })
  observe({
    a <- geometry()
    nodes <- lapply(seq_len(nrow(a)),function(i)
      list(start=a$bin_start[i],x=a$x[i],y=a$y[i],z=a$z[i],anchor=a$anchor[i]))
    session$sendCustomMessage("geometry",list(nodes=nodes))
  })
  observeEvent(input$reset,session$sendCustomMessage("reset_geometry",list()))
  output$locus <- renderUI({
    a <- geometry()
    tagList(h2(paste(input$gene,"·",label(input$model))),
      p(class="note",sprintf("%s:%s–%s · %d bins · GRCh38",a$chr[1],
        format(min(a$bin_start),big.mark=",",scientific=FALSE),
        format(max(a$bin_start)+25000,big.mark=",",scientific=FALSE),nrow(a))))
  })
  output$quality <- renderText({
    req(input$model,input$gene)
    d <- qc[qc$model==input$model & qc$gene==input$gene,]
    sprintf("Distance rank agreement %.2f · 3D eigenvalue fraction %.2f",
            d$positive_pair_distance_rank_rho,d$fit_eigenvalue_fraction)
  })
  output$dep_id <- renderUI({
    req(input$model)
    a <- models[models$model==input$model,]
    p(class="note",tags$a(a$ModelID,href=paste0("https://depmap.org/portal/cell_line/",a$ModelID)),
      " · ",a$RRID)
  })
  output$metrics <- renderUI({
    d <- gene_data()
    d <- d[d$model==input$model,]
    div(class="metrics",lapply(seq_len(nrow(d)),function(i)
      div(tags$span(d$metric[i]),tags$strong(if(is.finite(d$value[i])) sprintf("%.2f",d$value[i]) else "Unavailable"))))
  })
  output$comparison <- renderPlot({
    d <- gene_data()
    par(mfrow=c(2,1),mar=c(2.5,6,1.7,1),las=1,bty="n",mgp=c(1.5,.45,0))
    for(metric in unique(d$metric)){
      a <- d[d$metric==metric,]
      y <- seq_len(nrow(a))
      bounds <- range(c(0,a$value,-.05,.05),finite=TRUE)
      plot(NA,xlim=extendrange(bounds,f=.14),ylim=c(.6,length(y)+.4),yaxt="n",
           xlab="",ylab="",main=metric,cex.main=.93)
      axis(2,at=y,labels=label(a$model),tick=FALSE)
      abline(v=0,col="#CCD8DF",lty=2)
      colors <- ifelse(a$model==input$model,"#146D77","#879BA8")
      segments(0,y,a$value,y,col=colors,lwd=2)
      points(a$value,y,col=colors,pch=19)
      if(anyNA(a$value)) text(mean(bounds),y[is.na(a$value)],"Unavailable",cex=.75)
    }
  })
  output$concordance <- renderTable({
    req(input$gene)
    d <- rho[rho$gene==input$gene,]
    data.frame(First=label(d$model1),Second=label(d$model2),
               "Shared bin pairs"=d$n_pairs,"Rank correlation"=d$rho,check.names=FALSE)
  },digits=3,striped=TRUE,width="100%")
  output$coords <- downloadHandler(filename=function() paste(input$model,input$gene,"3d.csv",sep="_"),
    content=function(file) write.csv(geometry(),file,row.names=FALSE))
  output$depmap <- downloadHandler(filename=function() paste0(input$gene,"_DepMap_24Q4.csv"),
    content=function(file) write.csv(gene_data(),file,row.names=FALSE))
}
shinyApp(ui,server)
