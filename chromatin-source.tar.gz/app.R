library(shiny)
xyz <- read.csv("data/Review_3D_coordinates.csv")
qc <- read.csv("data/Review_3D_diagnostics.csv")
rho <- read.csv("data/review_contact_concordance.csv")
models <- read.csv("data/depmap_models.csv")
dep <- read.csv(gzfile("data/depmap_values.csv.gz"))
dep_by_gene <- split(seq_len(nrow(dep)), dep$gene)
assay_metrics <- c("RNA log2(TPM + 1)", "CRISPR gene effect")
panels <- read.delim("data/review_panels.tsv")
hic_genes <- sort(unique(xyz$gene))
genes <- sort(union(hic_genes, names(dep_by_gene)))
stopifnot(all(unique(dep$model) %in% models$model), !anyDuplicated(models$model))
label <- function(ids) models$CellLineName[match(ids,models$model)]

ui <- fluidPage(
  tags$head(tags$link(rel="stylesheet",href=paste0(getOption("chromatin.assetPrefix", ""), "app.css")),tags$script(src=paste0(getOption("chromatin.assetPrefix", ""), "structure.js"))),
  tags$header(tags$div(class="frame",h1("Cervical cancer chromatin explorer"),
                      p("Explore inferred 3D Hi-C structures and matched DepMap measurements."))),
  tags$main(class="frame",
    div(class="controls",selectInput("panel","Research panel",c("All loci",panels$project)),
        selectizeInput("gene","Gene (search by symbol)",choices=NULL),
        selectInput("model","Cell line",setNames(models$model,models$CellLineName),selected="SiHa")),
    div(class="columns",
      tags$section(class="card",
        div(class="cardhead",uiOutput("locus"),conditionalPanel("output.has_structure",actionButton("reset","Reset view"))),
        conditionalPanel("output.has_structure",
          tags$canvas(id="structure",tabindex="0",role="img"),
          p(class="note","Drag or use arrow keys to rotate. Scroll or use +/− to zoom. Red marks the promoter bin."),
          textOutput("quality"),br(),downloadButton("coords","Download coordinates")),
        conditionalPanel("!output.has_structure",
          p(class="note","A 3D Hi-C reconstruction is unavailable for this gene and cell line. The bundled structures cover 61 loci in SiHa, Ca Ski and C-33 A."))),
      tags$section(class="card",h2("DepMap context"),uiOutput("dep_id"),
        uiOutput("metrics"),plotOutput("comparison",height="550px"),
        p(class="note","More negative CRISPR scores indicate stronger loss of viability after knockout. × indicates a missing measurement."),
        downloadButton("depmap","Download gene data"))),
    tags$section(class="card wide",h2("Local Hi-C concordance"),
        p(class="note","Rank correlations within distance bands from 50 to 500 kb."),
        tableOutput("concordance")),
    tags$details(class="card wide",tags$summary("Sources and interpretation"),
      p("The three SCC maps use 25 kb GRCh38 cis contacts from GEO GSE195631. Coordinates are independently fitted from population-averaged Hi-C using classical multidimensional scaling. Distances and orientations are arbitrary."),
      p("The cell-line selector includes every model classified by DepMap Public 24Q4 as a Cervix cell line. The gene selector includes every symbol measured in at least one of those models, plus all bundled Hi-C loci. DepMap model classification and assay coverage vary. These assays are independent of the Hi-C measurements."),
      p("Search uses the gene symbols supplied by the release. If a symbol maps to multiple Entrez IDs, the download lists them separately and the comparison shows each measurement."),
      tags$a("GEO GSE195631",href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE195631")," · ",
      tags$a("DepMap Public 24Q4",href="https://doi.org/10.25452/figshare.plus.27993248.v1"))
  )
)

server <- function(input,output,session){
  updateSelectizeInput(session, "gene", choices=genes, selected="MECOM", server=TRUE)
  observeEvent(input$panel,{
    choices <- if(input$panel=="All loci") genes else
      sort(strsplit(panels$genes[match(input$panel,panels$project)]," ",fixed=TRUE)[[1]])
    previous <- isolate(input$gene)
    updateSelectizeInput(session,"gene",choices=choices,selected=if(previous %in% choices) previous else choices[1],server=TRUE)
  },ignoreInit=TRUE)
  geometry <- reactive({
    req(input$model,input$gene)
    x <- xyz[xyz$model==input$model & xyz$gene==input$gene,]
    x[order(x$bin_start),]
  })
  gene_data <- reactive({
    req(input$gene)
    d <- dep[dep_by_gene[[input$gene]],,drop=FALSE]
    if (!nrow(d)) return(d)
    template <- expand.grid(model=models$model, metric=assay_metrics,
                            stringsAsFactors=FALSE)
    d <- merge(template,d,by=c("model","metric"),all.x=TRUE,sort=FALSE)
    d$gene <- input$gene
    d$ModelID <- models$ModelID[match(d$model,models$model)]
    d
  })
  output$has_structure <- reactive(nrow(geometry()) > 0)
  outputOptions(output, "has_structure", suspendWhenHidden=FALSE)
  observe({
    a <- geometry()
    nodes <- lapply(seq_len(nrow(a)),function(i)
      list(start=a$bin_start[i],x=a$x[i],y=a$y[i],z=a$z[i],anchor=a$anchor[i]))
    session$sendCustomMessage("geometry",list(nodes=nodes))
  })
  observeEvent(input$reset,session$sendCustomMessage("reset_geometry",list()))
  output$locus <- renderUI({
    a <- geometry()
    heading <- h2(paste(input$gene,"·",label(input$model)))
    if(!nrow(a)) return(heading)
    tagList(heading,
      p(class="note",sprintf("%s:%s–%s · %d bins · GRCh38",a$chr[1],
        format(min(a$bin_start),big.mark=",",scientific=FALSE),
        format(max(a$bin_start)+25000,big.mark=",",scientific=FALSE),nrow(a))))
  })
  output$quality <- renderText({
    req(input$model,input$gene)
    d <- qc[qc$model==input$model & qc$gene==input$gene,]
    req(nrow(d)>0)
    sprintf("Distance rank agreement %.2f · 3D eigenvalue fraction %.2f",
            d$positive_pair_distance_rank_rho,d$fit_eigenvalue_fraction)
  })
  output$dep_id <- renderUI({
    req(input$model)
    a <- models[models$model==input$model,]
    p(class="note",tags$a(a$ModelID,href=paste0("https://depmap.org/portal/cell_line/",a$ModelID)),
      " · ",a$RRID)
  })
  output$metrics <- renderUI({
    d <- gene_data()
    d <- d[d$model==input$model,]
    div(class="metrics",lapply(assay_metrics,function(metric) {
      a <- d[d$metric==metric & is.finite(d$value),]
      measurement <- if(nrow(a)==0) "Unavailable" else if(nrow(a)==1)
        sprintf("%.2f",a$value) else paste(sprintf("%.2f (Entrez %s)",a$value,a$entrez_id),collapse=", ")
      div(tags$span(metric),tags$strong(measurement))
    }))
  })
  output$comparison <- renderPlot({
    d <- gene_data()
    validate(need(any(is.finite(d$value)), "No DepMap measurements for this gene."))
    par(mfrow=c(1,2),mar=c(2.5,6,2,1),las=1,bty="n",mgp=c(1.5,.45,0))
    for(metric in assay_metrics){
      a <- d[d$metric==metric,]
      model_order <- rev(models$model)
      y <- match(a$model,model_order)
      bounds <- range(c(0,a$value,-.05,.05),finite=TRUE)
      plot(NA,xlim=extendrange(bounds,f=.14),ylim=c(.6,length(model_order)+.4),yaxt="n",
           xlab="",ylab="",main=metric,cex.main=.93)
      axis(2,at=seq_along(model_order),labels=label(model_order),tick=FALSE,cex.axis=.72)
      abline(v=0,col="#CCD8DF",lty=2)
      colors <- ifelse(a$model==input$model,"#146D77","#879BA8")
      segments(0,y,a$value,y,col=colors,lwd=2)
      points(a$value,y,col=colors,pch=19)
      points(rep(mean(bounds),sum(is.na(a$value))),y[is.na(a$value)],pch=4,col="#879BA8",cex=.6)
    }
  })
  output$concordance <- renderTable({
    req(input$gene)
    d <- rho[rho$gene==input$gene,]
    validate(need(nrow(d)>0,"No Hi-C contact comparison is available for this gene."))
    data.frame(First=label(d$model1),Second=label(d$model2),
               "Shared bin pairs"=d$n_pairs,"Rank correlation"=d$rho,check.names=FALSE)
  },digits=3,striped=TRUE,width="100%")
  output$coords <- downloadHandler(filename=function() paste(input$model,input$gene,"3d.csv",sep="_"),
    content=function(file) write.csv(geometry(),file,row.names=FALSE))
  output$depmap <- downloadHandler(filename=function() paste0(input$gene,"_DepMap_24Q4.csv"),
    content=function(file) write.csv(gene_data(),file,row.names=FALSE))
}
shinyApp(ui,server)
