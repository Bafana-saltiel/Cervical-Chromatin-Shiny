library(shiny)
hic_directory <- normalizePath("data/hic_bands")
hic_models <- read.csv("data/hic_models.csv", stringsAsFactors = FALSE)
hic_models <- hic_models[dir.exists(file.path(hic_directory, hic_models$model)),]
loci <- read.csv(gzfile("data/gene_loci.csv.gz"), stringsAsFactors = FALSE)
source("R/hic_windows.R", local = TRUE)
source("R/patient_cohort.R", local = TRUE)
source("R/public_cohorts.R", local = TRUE)
source("R/drug_models.R", local = TRUE)
source("R/drug_explanations.R", local = TRUE)
drug_samples <- read.csv("data/drug_hic_sources.csv", stringsAsFactors = FALSE)
loci_hg19 <- read.csv(gzfile("data/gene_loci_hg19.csv.gz"), stringsAsFactors = FALSE)
tcga <- read.csv(gzfile("data/tcga_cesc_expression_summary.csv.gz"), stringsAsFactors = FALSE)
cra <- read.csv("data/cra001401_summary.csv", stringsAsFactors = FALSE)
models <- read.csv("data/depmap_models.csv")
dep <- read.csv(gzfile("data/depmap_values.csv.gz"))
dep_by_gene <- split(seq_len(nrow(dep)), dep$gene)
assay_metrics <- c("RNA log2(TPM + 1)", "CRISPR gene effect")
panels <- read.delim("data/review_panels.tsv")
genes <- sort(union(loci$gene, names(dep_by_gene)))
stopifnot(all(unique(dep$model) %in% models$model), !anyDuplicated(models$model))
model_labels <- setNames(models$CellLineName, models$model)
reference <- hic_models[!hic_models$model %in% models$model,]
model_labels <- c(model_labels, setNames(reference$label, reference$model))
label <- function(ids) unname(model_labels[ids])

ui <- fluidPage(
  tags$head(tags$link(rel="stylesheet",href=paste0(getOption("chromatin.assetPrefix", ""), "app.css")),tags$script(src=paste0(getOption("chromatin.assetPrefix", ""), "structure.js"))),
  tags$header(tags$div(class="frame",h1("Cervical cancer chromatin explorer"),
                      p("Explore inferred 3D Hi-C structures and matched DepMap measurements."))),
  tags$main(class="frame",
    tabsetPanel(id="analysis_tab",
      tabPanel("Cell lines",
    div(class="controls",selectInput("panel","Research panel",c("All loci",panels$project)),
        selectizeInput("gene","Gene (search by symbol)",choices=NULL),
        selectInput("model","Cell line",setNames(names(model_labels), model_labels),selected="SiHa")),
    div(class="columns",
      tags$section(class="card",
        div(class="cardhead",uiOutput("locus"),conditionalPanel("output.has_structure",actionButton("reset","Reset view"))),
        conditionalPanel("output.has_structure",
          tags$canvas(id="structure",tabindex="0",role="img"),
          p(class="note","Drag or use arrow keys to rotate. Scroll or use +/− to zoom. Red marks the promoter bin."),
          textOutput("quality"),br(),downloadButton("coords","Download coordinates")),
        conditionalPanel("!output.has_structure",
          textOutput("missing_structure")),
        tags$details(tags$summary("Use your own Hi-C contacts"),
          p(class="note","Optional CSV for the selected gene and line. Use normalized GRCh38 25 kb contact pairs with columns chr, start1, start2 and balanced. Coordinates are zero-based bin starts. The app uses a window of ±500 kb around the selected transcription start site. The upload is used in the current Shiny session."),
          fileInput("hic_upload","Upload normalized contact pairs",accept=".csv"),
          textOutput("upload_status"))),
      tags$section(class="card",h2("DepMap context"),uiOutput("dep_id"),
        uiOutput("metrics"),plotOutput("comparison",height="550px"),
        p(class="note","More negative CRISPR scores indicate stronger loss of viability after knockout. × indicates a missing measurement."),
        downloadButton("depmap","Download gene data"))),
    tags$section(class="card wide",h2("Local Hi-C concordance"),
        p(class="note","Bundled Hi-C maps compared within distance bands from 50 to 500 kb."),
        tableOutput("concordance")),
    tags$details(class="card wide",tags$summary("Sources and interpretation"),
      p("The viewer fits 25 kb GRCh38 cis contacts for any annotated gene with sufficient local coverage. It selects a RefSeq Select transcription start site when available, with Curated RefSeq as a fallback. Coordinates are independently fitted from population-averaged Hi-C using classical multidimensional scaling. Distances and orientations are arbitrary."),
      uiOutput("hic_sources"),
      p("The cell-line selector includes every model classified by DepMap Public 24Q4 as a Cervix cell line. The gene selector includes every symbol measured in at least one of those models, plus all genes with a bundled RefSeq locus. DepMap model classification and assay coverage vary. These assays are independent of the Hi-C measurements."),
      p("Search uses the gene symbols supplied by the release. If a symbol maps to multiple Entrez IDs, the download lists them separately and the comparison shows each measurement."),
      tags$a("GEO GSE195631",href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE195631")," · ",
      tags$a("DepMap Public 24Q4",href="https://doi.org/10.25452/figshare.plus.27993248.v1"))),
      patient_cohort_ui(), public_cohorts_ui(), drug_models_ui(drug_samples))
  )
)

server <- function(input,output,session){
  serve_patient_cohort(input, output, session, loci, loci_hg19)
  serve_public_cohorts(input, output, session, tcga, cra)
  serve_drug_models(input, output, session, loci, drug_samples)
  observeEvent(input$drug_hela_reference, {
    gene <- req(input$drug_gene)
    updateSelectInput(session,"panel",selected="All loci")
    updateSelectInput(session,"model",selected="ACH-001086")
    updateSelectizeInput(session,"gene",choices=genes,selected=gene,server=TRUE)
    updateTabsetPanel(session,"analysis_tab",selected="Cell lines")
  })
  updateSelectizeInput(session, "gene", choices=genes, selected="MECOM", server=TRUE)
  observeEvent(input$panel,{
    choices <- if(input$panel=="All loci") genes else
      sort(strsplit(panels$genes[match(input$panel,panels$project)]," ",fixed=TRUE)[[1]])
    previous <- isolate(input$gene)
    updateSelectizeInput(session,"gene",choices=choices,selected=if(previous %in% choices) previous else choices[1],server=TRUE)
  },ignoreInit=TRUE)
  locus <- reactive({
    req(input$gene)
    loci[loci$gene == input$gene,,drop = FALSE]
  })
  upload <- reactiveVal(NULL)
  observeEvent(input$hic_upload, {
    req(input$model, nrow(locus()) == 1L)
    x <- tryCatch(read_uploaded_window(input$hic_upload$datapath, locus()),
                  error = function(e) conditionMessage(e))
    upload(list(model = input$model, gene = input$gene, data = x))
  })
  selected_upload <- reactive({
    item <- upload()
    if (is.null(item) || !identical(item$model, input$model) ||
        !identical(item$gene, input$gene)) return(NULL)
    item$data
  })
  experiment <- reactive({
    req(input$model, input$gene)
    annotation <- locus()
    if (!nrow(annotation)) return(NULL)
    x <- selected_upload()
    bundled <- is.null(x) || is.character(x)
    if (bundled) x <- read_hic_window(input$model, annotation)
    fit <- fit_hic_window(x, input$model, annotation)
    if (!is.null(fit)) {
      source <- if (bundled) hic_models$accession[match(input$model, hic_models$model)] else "User-uploaded CSV"
      fit$coordinates$source <- source
      fit$coordinates$reference_transcript <- annotation$transcript
    }
    fit
  })
  geometry <- reactive(experiment()$coordinates)
  output$upload_status <- renderText({
    x <- selected_upload()
    if (is.character(x)) x else if (!is.null(x)) "Using uploaded contacts for this gene and cell line."
  })
  output$missing_structure <- renderText({
    req(input$model, input$gene)
    if (!nrow(locus())) "This gene has no matched GRCh38 RefSeq transcription start site." else
      if (!input$model %in% hic_models$model && is.null(selected_upload()))
        "A measured Hi-C contact map is unavailable for this cell line. You can upload normalized contacts below." else
        "The selected locus has too few usable Hi-C contacts for a 3D reconstruction."
  })
  output$hic_sources <- renderUI({
    tagList(lapply(seq_len(nrow(hic_models)), function(i) {
      row <- hic_models[i,]
      p(class="note", tags$a(paste(row$label, row$accession), href=row$source_url),
        paste("·", row$normalization, "normalization"))
    }))
  })
  gene_data <- reactive({
    req(input$gene)
    d <- dep[dep_by_gene[[input$gene]],,drop=FALSE]
    if (!nrow(d)) return(d)
    template <- expand.grid(model=models$model, metric=assay_metrics,
                            stringsAsFactors=FALSE)
    d <- merge(template,d,by=c("model","metric"),all.x=TRUE,sort=FALSE)
    d$gene <- input$gene
    d$ModelID <- models$ModelID[match(d$model,models$model)]
    d
  })
  output$has_structure <- reactive(!is.null(geometry()))
  outputOptions(output, "has_structure", suspendWhenHidden=FALSE)
  observe({
    a <- geometry()
    nodes <- lapply(seq_len(NROW(a)),function(i)
      list(start=a$bin_start[i],x=a$x[i],y=a$y[i],z=a$z[i],anchor=a$anchor[i]))
    session$sendCustomMessage("geometry",list(nodes=nodes))
  })
  observeEvent(input$reset,session$sendCustomMessage("reset_geometry",list()))
  output$locus <- renderUI({
    a <- geometry()
    heading <- h2(paste(input$gene,"·",label(input$model)))
    if(is.null(a)) return(heading)
    tagList(heading,
      p(class="note",sprintf("%s:%s–%s · %d bins · GRCh38",a$chr[1],
        format(min(a$bin_start),big.mark=",",scientific=FALSE),
        format(max(a$bin_start)+25000,big.mark=",",scientific=FALSE),nrow(a))),
        p(class="note", paste(locus()$transcript[1], "·", locus()$source[1], "·", a$source[1])))
  })
  output$quality <- renderText({
    fit <- req(experiment())
    sprintf("Distance rank agreement %.2f · 3D eigenvalue fraction %.2f",
            fit$agreement, fit$fraction)
  })
  output$dep_id <- renderUI({
    req(input$model)
    a <- models[models$model==input$model,]
    if (!nrow(a)) return(p(class="note","This Hi-C reference has no matched DepMap model. The comparison below shows the other cell lines."))
    p(class="note",tags$a(a$ModelID,href=paste0("https://depmap.org/portal/cell_line/",a$ModelID)),
      " · ",a$RRID)
  })
  output$metrics <- renderUI({
    d <- gene_data()
    d <- d[d$model==input$model,]
    div(class="metrics",lapply(assay_metrics,function(metric) {
      a <- d[d$metric==metric & is.finite(d$value),]
      measurement <- if(nrow(a)==0) "Unavailable" else if(nrow(a)==1)
        sprintf("%.2f",a$value) else paste(sprintf("%.2f (Entrez %s)",a$value,a$entrez_id),collapse=", ")
      div(tags$span(metric),tags$strong(measurement))
    }))
  })
  output$comparison <- renderPlot({
    d <- gene_data()
    validate(need(any(is.finite(d$value)), "No DepMap measurements for this gene."))
    par(mfrow=c(1,2),mar=c(2.5,6,2,1),las=1,bty="n",mgp=c(1.5,.45,0))
    for(metric in assay_metrics){
      a <- d[d$metric==metric,]
      model_order <- rev(models$model)
      y <- match(a$model,model_order)
      bounds <- range(c(0,a$value,-.05,.05),finite=TRUE)
      plot(NA,xlim=extendrange(bounds,f=.14),ylim=c(.6,length(model_order)+.4),yaxt="n",
           xlab="",ylab="",main=metric,cex.main=.93)
      axis(2,at=seq_along(model_order),labels=label(model_order),tick=FALSE,cex.axis=.72)
      abline(v=0,col="#CCD8DF",lty=2)
      colors <- ifelse(a$model==input$model,"#146D77","#879BA8")
      segments(0,y,a$value,y,col=colors,lwd=2)
      points(a$value,y,col=colors,pch=19)
      points(rep(mean(bounds),sum(is.na(a$value))),y[is.na(a$value)],pch=4,col="#879BA8",cex=.6)
    }
  })
  output$concordance <- renderTable({
    annotation <- locus()
    validate(need(nrow(annotation) == 1L, "No matched GRCh38 locus for this gene."))
    windows <- setNames(lapply(hic_models$model, read_hic_window, locus=annotation), hic_models$model)
    windows <- Filter(function(x) !is.null(x) && length(x$bins) >= 8L, windows)
    validate(need(length(windows) >= 2L, "Fewer than two Hi-C maps cover this locus."))
    rows <- combn(names(windows), 2L, simplify=FALSE, FUN=function(pair)
      compare_hic_windows(windows[[pair[1]]], windows[[pair[2]]], label(pair)))
    do.call(rbind, rows)
  }, digits=3, striped=TRUE, width="100%")
  output$coords <- downloadHandler(filename=function() paste(input$model,input$gene,"3d.csv",sep="_"),
    content=function(file) write.csv(geometry(),file,row.names=FALSE))
  output$depmap <- downloadHandler(filename=function() paste0(input$gene,"_DepMap_24Q4.csv"),
    content=function(file) write.csv(gene_data(),file,row.names=FALSE))
}
shinyApp(ui,server)
