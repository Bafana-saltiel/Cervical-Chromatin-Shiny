# Build the public example from the four NCBI GEO .mcool files.
library(rhdf5)
root <- commandArgs(trailingOnly=TRUE)[1]
samples <- read.csv("data/experiment_example_samples.csv", stringsAsFactors=FALSE)
extract <- function(id) {
  file <- file.path(root,paste0(id,".mcool"))
  group <- "/resolutions/250000/"
  get <- function(name, ...) h5read(file,paste0(group,name), ...)
  chrom <- match("chr14",get("chroms/name"))
  stopifnot(!is.na(chrom))
  offsets <- as.numeric(get("indexes/chrom_offset"))
  lo <- offsets[chrom]
  hi <- offsets[chrom+1L]
  n <- hi-lo
  starts <- get("bins/start",start=lo+1,count=n)
  weights <- get("bins/weight",start=lo+1,count=n)
  bounds <- get("indexes/bin1_offset",index=list(c(lo+1,hi+1)))
  pixels <- function(name) as.numeric(get(paste0("pixels/",name),start=bounds[1]+1,count=diff(bounds)))
  i <- pixels("bin1_id"); j <- pixels("bin2_id")
  cis <- j<hi & j>=lo
  score <- matrix(0,n,n)
  score[cbind(i[cis]-lo+1,j[cis]-lo+1)] <- pixels("count")[cis]
  score <- score*outer(weights,weights)
  ij <- which(upper.tri(score,diag=TRUE) & is.finite(score),arr.ind=TRUE)
  data.frame(sample_id=id,chromosome="chr14",bin1=starts[ij[,1]],bin2=starts[ij[,2]],contact=score[ij])
}
out <- do.call(rbind,lapply(samples$sample_id,extract))
table(out$sample_id) |> print()
con <- gzfile("data/experiment_example_contacts.csv.gz","wt")
write.csv(out,con,row.names=FALSE)
close(con)
