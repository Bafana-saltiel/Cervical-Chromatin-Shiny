# Rscript scripts/mcool_bands.R MODEL path/to/map.mcool
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2L)
model <- args[1]
path <- args[2]
suppressPackageStartupMessages(library(rhdf5))
get <- function(key, ...) h5read(path, paste0("/resolutions/25000/",key), ...)
chrom <- get("chroms/name")
chrom <- ifelse(startsWith(chrom,"chr"),chrom,paste0("chr",chrom))
stopifnot(get("chroms/length")[match("chr1",chrom)]==248956422)
offset <- as.numeric(get("indexes/chrom_offset"))
bin_offset <- as.numeric(get("indexes/bin1_offset"))
output <- file.path("data","hic_bands",model)
dir.create(output,recursive=TRUE,showWarnings=FALSE)
for (k in which(chrom %in% paste0("chr",c(1:22,"X","Y")))) {
  lo <- offset[k]
  hi <- offset[k+1L]
  count <- hi-lo
  weight <- as.numeric(get("bins/weight", start=lo+1L,count=count))
  contacts <- matrix(0,41L,count)
  for (left in seq.int(lo,hi-1L,by=200L)) {
    end <- min(hi,left+200L)
    p0 <- bin_offset[left+1L]
    size <- bin_offset[end+1L]-p0
    if (size==0L) next
    pixels <- function(key) as.numeric(get(paste0("pixels/",key),start=p0+1L,count=size))
    a <- pixels("bin1_id")
    b <- pixels("bin2_id")
    delta <- b-a
    keep <- b<hi & delta>=0L & delta<=40L
    a <- a[keep]-lo+1L
    b <- b[keep]-lo+1L
    z <- pixels("count")[keep]*weight[a]*weight[b]
    valid <- is.finite(z) & z>0
    contacts[cbind(delta[keep][valid]+1L,a[valid])] <- z[valid]
  }
  con <- gzfile(file.path(output,paste0(chrom[k],".bin.gz")),"wb",compression=6)
  writeBin(as.integer(count),con,endian="little")
  writeBin(as.vector(contacts),con,size=4L,endian="little")
  close(con)
  cat(model,chrom[k],sum(contacts>0),"\n",sep="\t")
}
