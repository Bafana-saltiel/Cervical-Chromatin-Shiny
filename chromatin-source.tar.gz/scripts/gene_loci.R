# Rscript scripts/gene_loci.R RefSeqSelect.txt.gz ncbiRefSeqCurated.txt.gz
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
read_reference <- function(path, source) {
  raw <- read.delim(gzfile(path), header = FALSE, quote = "", colClasses = "character")
  data.frame(gene = raw[[13]], transcript = raw[[2]], chr = raw[[3]], strand = raw[[4]],
             tss0 = ifelse(raw[[4]] == "+", as.numeric(raw[[5]]), as.numeric(raw[[6]]) - 1),
             source = source)
}
refs <- rbind(read_reference(args[1], "RefSeq Select"),
              read_reference(args[2], "Curated RefSeq"))
refs <- subset(refs, chr %in% paste0("chr", c(1:22, "X", "Y")) & nzchar(gene) &
                 is.finite(tss0) & strand %in% c("+", "-"))
refs <- refs[order(refs$gene, refs$source != "RefSeq Select",
                   !startsWith(refs$transcript, "NM_"), refs$transcript, refs$tss0),]
refs <- refs[!duplicated(refs$gene),]
out <- gzfile("data/gene_loci.csv.gz", "wt")
write.csv(refs, out, row.names = FALSE)
close(out)
