# Rscript scripts/export_reanalysis_mcool.R maps.csv resolution chr1,chr2 contacts.csv.gz
# maps.csv columns: sample_id,path. Maps must share an assembly and use Cooler multiplicative weights.
args <- commandArgs(trailingOnly=TRUE)
if(length(args)!=4L) stop("Provide maps.csv, resolution, comma-separated chromosomes, output.csv.gz")
suppressPackageStartupMessages(library(rhdf5))
samples <- read.csv(args[1],colClasses="character")
width <- suppressWarnings(as.integer(args[2]))
requested <- strsplit(args[3],",",fixed=TRUE)[[1]]
stopifnot(all(c("sample_id","path")%in%names(samples)),nrow(samples)>=2L,
          !anyDuplicated(samples$sample_id),all(file.exists(samples$path)),
          !is.na(width),width>0L,length(requested)>0L,!anyDuplicated(requested))

extract <- function(file,id,chr) {
  group <- paste0("/resolutions/",width,"/")
  get <- function(name,...) h5read(file,paste0(group,name),...)
  k <- match(chr,as.character(get("chroms/name")))
  if(is.na(k)) stop("Chromosome ",chr," is missing in ",id)
  offsets <- as.numeric(get("indexes/chrom_offset"))
  lo <- offsets[k]; hi <- offsets[k+1L]; n <- hi-lo
  if(n<5L || n>600L) stop(chr," has ",n," bins. Choose a resolution with 5–600 bins per chromosome.")
  starts <- as.numeric(get("bins/start",start=lo+1,count=n))
  weights <- as.numeric(get("bins/weight",start=lo+1,count=n))
  bounds <- as.numeric(get("indexes/bin1_offset",index=list(c(lo+1,hi+1))))
  score <- matrix(0,n,n)
  if(diff(bounds)>0L) {
    pixels <- function(name) as.numeric(get(paste0("pixels/",name),start=bounds[1]+1,count=diff(bounds)))
    i <- pixels("bin1_id"); j <- pixels("bin2_id"); cis <- j<hi & j>=lo
    score[cbind(i[cis]-lo+1,j[cis]-lo+1)] <- pixels("count")[cis]
  }
  score <- score*outer(weights,weights)
  ij <- which(upper.tri(score,diag=TRUE)&is.finite(score)&score>=0,arr.ind=TRUE)
  data.frame(sample_id=rep(id,nrow(ij)),chromosome=rep(chr,nrow(ij)),
             bin1=starts[ij[,1]],bin2=starts[ij[,2]],contact=score[ij])
}
write_contacts <- function(path) {
  con <- gzfile(path,"wt")
  on.exit(close(con),add=TRUE)
  header <- TRUE
  for(i in seq_len(nrow(samples))) for(chr in requested) {
    d <- extract(samples$path[i],samples$sample_id[i],chr)
    write.table(d,con,sep=",",row.names=FALSE,col.names=header)
    header <- FALSE
  }
}
write_contacts(args[4])
