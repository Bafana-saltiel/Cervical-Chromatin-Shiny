loci <- read.csv("data/review_panel_loci.csv")
models <- read.csv("data/cell_line_sources.csv")$model
data <- setNames(lapply(models,function(m)
  read.csv(gzfile(file.path("data","review_local_contacts",paste0(m,".csv.gz"))))),models)
pairs <- combn(models,2,simplify=FALSE)
rows <- list()
for (g in loci$gene) {
  contacts <- lapply(data,function(d) d[d$gene==g,])
  for (p in pairs) {
    x <- contacts[[p[1]]]; y <- contacts[[p[2]]]
    bins <- intersect(unique(c(x$start1[is.finite(x$balanced)],x$start2[is.finite(x$balanced)])),unique(c(y$start1[is.finite(y$balanced)],y$start2[is.finite(y$balanced)])))
    key <- subset(expand.grid(start1=bins,start2=bins),
                  start2-start1>=50000 & start2-start1<=500000)
    match_counts <- function(d) {
      idx <- match(paste(key$start1,key$start2),paste(d$start1,d$start2))
      z <- d$balanced[idx]
      z[is.na(idx)] <- 0
      z
    }
    vx <- match_counts(x); vy <- match_counts(y)
    ok <- is.finite(vx) & is.finite(vy)
    key <- key[ok,,drop=FALSE]; vx <- vx[ok]; vy <- vy[ok]
    bands <- split(seq_len(nrow(key)),key$start2-key$start1)
    bands <- Filter(function(i) length(i)>=5L &&
                      length(unique(vx[i]))>1L && length(unique(vy[i]))>1L,bands)
    ranks <- function(z) unlist(lapply(bands,function(i)
      (rank(z[i],ties.method="average")-.5)/length(i)),use.names=FALSE)
    a <- ranks(vx); b <- ranks(vy)
    rows[[length(rows)+1L]] <- data.frame(gene=g,model1=p[1],model2=p[2],
                           n_pairs=length(a),rho=if(length(a)>=10L) cor(a,b) else NA_real_)
  }
}
z <- do.call(rbind,rows)
write.csv(z,"data/review_contact_concordance.csv",row.names=FALSE)
panel <- read.delim("data/review_panels.tsv")
labels <- vapply(pairs,paste,character(1),collapse=" / ")
