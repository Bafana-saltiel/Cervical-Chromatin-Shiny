# Rscript scripts/tcga_expression.R XENA_EXPRESSION.tsv.gz XENA_CLINICAL.tsv
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2L)
clinical <- read.delim(args[2],check.names=FALSE,quote="",stringsAsFactors=FALSE)
expression <- read.delim(gzfile(args[1]),check.names=FALSE,quote="",stringsAsFactors=FALSE)
id <- names(expression)[-1L]
stopifnot(!anyDuplicated(clinical$sampleID), !anyDuplicated(id))
idx <- match(id,clinical$sampleID)
primary <- !is.na(idx) & grepl("-01$",id) & clinical$sample_type[idx]=="Primary Tumor"
stopifnot(any(primary), !anyDuplicated(clinical[["_PATIENT"]][idx[primary]]))
hist <- clinical$histological_type[idx]
groups <- list("All primary tumours"=which(primary),
  "Squamous cell carcinoma"=which(primary & hist=="Cervical Squamous Cell Carcinoma"),
  "Adenocarcinoma"=which(primary & grepl("adenocarcinoma",hist,ignore.case=TRUE)),
  "Adenosquamous carcinoma"=which(primary & hist=="Adenosquamous"))
gene <- expression[[1L]]
valid <- !is.na(gene) & nzchar(gene) & gene != "?" & !duplicated(gene)
results <- lapply(names(groups), function(label) {
  columns <- groups[[label]]
  stopifnot(length(columns)>0)
  x <- as.matrix(expression[valid, columns + 1L, drop=FALSE])
  q <- t(apply(x,1,function(y) quantile(y,c(.25,.5,.75),na.rm=TRUE,names=FALSE)))
  data.frame(gene=gene[valid],group=label,n=rowSums(is.finite(x)),
             q1=q[,1],median=q[,2],q3=q[,3])
})
con <- gzfile("data/tcga_cesc_expression_summary.csv.gz","wt")
write.csv(do.call(rbind,results),con,row.names=FALSE)
close(con)
print(lengths(groups))
cat(sum(valid),"gene symbols\n")
