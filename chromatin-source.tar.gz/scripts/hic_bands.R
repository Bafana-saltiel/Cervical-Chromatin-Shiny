# Rscript scripts/hic_bands.R MODEL path/to/map.hic
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
model <- args[1]
file <- args[2]
suppressPackageStartupMessages(library(strawr))
chrom <- readHicChroms(file)
chrom <- subset(chrom, name %in% paste0("chr", c(1:22, "X", "Y")))
stopifnot(chrom$length[match("chr1", chrom$name)] == 248956422,
          25000L %in% readHicBpResolutions(file))
norm <- if ("KR" %in% readHicNormTypes(file)) "KR" else
  stop("This build requires KR-normalized contacts.")
bin_size <- 25000L
max_offset <- 40L
tile <- 400L
output <- file.path("data", "hic_bands", model)
dir.create(output, recursive = TRUE, showWarnings = FALSE)
for (k in seq_len(nrow(chrom))) {
  chr <- chrom$name[k]
  count <- ceiling(chrom$length[k] / bin_size)
  contacts <- matrix(0, nrow = max_offset + 1L, ncol = count)
  for (start in seq.int(0L, count - 1L, by = tile)) {
    end <- min(chrom$length[k] - 1L, (start + tile + max_offset) * bin_size)
    range <- sprintf("%s:%d:%d", chr, start * bin_size, end)
    x <- straw(norm, file, range, range, "BP", bin_size)
    left <- x[[1]] %/% bin_size
    delta <- (x[[2]] - x[[1]]) %/% bin_size
    keep <- left >= start & left < start + tile & left < count &
      delta >= 0L & delta <= max_offset & is.finite(x[[3]]) & x[[3]] > 0
    contacts[cbind(delta[keep] + 1L, left[keep] + 1L)] <- x[[3]][keep]
  }
  path <- file.path(output, paste0(chr, ".bin.gz"))
  con <- gzfile(path, "wb", compression = 6)
  writeBin(as.integer(count), con, endian = "little")
  writeBin(as.vector(contacts), con, size = 4L, endian = "little")
  close(con)
  cat(model, chr, count, sum(contacts > 0), file.info(path)$size, "\n", sep = "\t")
}
