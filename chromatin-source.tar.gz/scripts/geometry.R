# Fit and render local 3D structures for the full review panel.
loci <- read.csv("data/review_panel_loci.csv")
models <- read.csv("data/cell_line_sources.csv")$model
coords <- qc <- list()
for (m in models) {
  con <- gzfile(file.path("data","review_local_contacts",paste0(m,".csv.gz")))
  d <- read.csv(con)
  for (g in loci$gene) {
    x <- d[d$gene==g & is.finite(d$balanced),]
    bins <- sort(unique(c(x$start1,x$start2)))
    l <- loci[match(g,loci$gene),]
    anchor <- floor(l$tss0/25000)*25000
    if(length(bins)<8 || !anchor %in% bins) next
    z <- matrix(0,length(bins),length(bins))
    i <- match(x$start1,bins); j <- match(x$start2,bins)
    z[cbind(i,j)] <- z[cbind(j,i)] <- x$balanced
    use <- upper.tri(z)&z>0
    if(sum(use)<8) next
    positive <- z[use]
    distance <- (pmax(z,as.numeric(quantile(positive,.1)))/median(positive))^(-1/3)
    diag(distance) <- 0
    fit <- suppressWarnings(cmdscale(as.dist(distance),k=3,eig=TRUE))
    if(ncol(fit$points)!=3 || !all(is.finite(fit$points))) next
    p <- fit$points
    id <- paste(m,g,sep=" | ")
    coords[[id]] <- data.frame(model=m,gene=g,chr=l$chr,bin_start=bins,
                    anchor=bins==anchor,x=p[,1],y=p[,2],z=p[,3])
    qc[[id]] <- data.frame(model=m,gene=g,bins=length(bins),
               fit_eigenvalue_fraction=fit$GOF[1],
               positive_pair_distance_rank_rho=cor(distance[use],as.matrix(dist(p))[use],
                                                     method="spearman"))
  }
}
write.csv(do.call(rbind,coords),"data/Review_3D_coordinates.csv",row.names=FALSE)
write.csv(do.call(rbind,qc),"data/Review_3D_diagnostics.csv",row.names=FALSE)
