# The length_2 class repeats the first two fragments of longer walks.
# Use only fragment index 1, which carries the first pair's distance.
BEGIN {
  FS = "\t"; OFS = ","
  print "sample_id,separation_lower_bp,separation_upper_bp,pairs"
}
NR > 1 && $(NF-1) == "length_2" && $13 == 1 && $17 == "False" && $18 + 0 >= 1000 {
  k = int(log($18 / 1000) / log(2))
  counts[$NF, k]++
}
END {
  for (key in counts) {
    split(key, parts, SUBSEP)
    print parts[1], 1000 * 2^parts[2], 1000 * 2^(parts[2]+1), counts[key]
  }
}
