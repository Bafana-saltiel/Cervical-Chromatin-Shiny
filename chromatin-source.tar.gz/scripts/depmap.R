# Rscript scripts/depmap.R [release-download-directory]
args <- commandArgs(trailingOnly=TRUE)
cache <- if(length(args)) args[1] else tempfile("depmap-")
dir.create(cache,showWarnings=FALSE,recursive=TRUE)
source <- read.csv("data/depmap_sources.csv")
for(i in seq_len(nrow(source))){
  path <- file.path(cache,source$file[i])
  if(!file.exists(path)){
    options(timeout=300)
    download.file(source$url[i],path,mode="wb")
  }
  stopifnot(unname(tools::md5sum(path))==source$md5[i])
}
models <- read.csv(file.path(cache,"Model.csv"),check.names=FALSE)
meta <- subset(models, OncotreeLineage == "Cervix" & ModelType == "Cell Line",
               select=c(ModelID, CellLineName, OncotreePrimaryDisease, OncotreeSubtype, RRID, CCLEName))
hic_models <- c("ACH-000556"="SiHa", "ACH-001336"="CaSki", "ACH-001333"="C33A")
stopifnot(all(names(hic_models) %in% meta$ModelID), !anyDuplicated(meta$ModelID))
meta$model <- unname(hic_models[meta$ModelID])
meta$model[is.na(meta$model)] <- meta$ModelID[is.na(meta$model)]
meta <- meta[order(tolower(meta$CellLineName)),]
write.csv(meta, "data/depmap_models.csv", row.names=FALSE)
mapping <- meta[c("model", "ModelID")]
subset_matrix <- function(file,metric) {
  con <- file(file.path(cache,file),"rt")
  on.exit(close(con))
  raw <- strsplit(readLines(con,n=1L),",",fixed=TRUE)[[1]]
  symbols <- sub(" \\([0-9]+\\)$","",raw)
  take <- which(grepl(" \\([0-9]+\\)$",raw))
  ids <- sub("^.* \\(([0-9]+)\\)$","\\1",raw[take])
  genes <- symbols[take]
  stopifnot(!anyDuplicated(raw[take]))
  out <- matrix(NA_real_,nrow(mapping),length(genes))
  seen <- character()
  repeat {
    lines <- readLines(con,n=80L)
    if(!length(lines)) break
    id <- sub(",.*","",lines)
    needed <- which(id %in% mapping$ModelID)
    for (j in needed) {
      stopifnot(!id[j] %in% seen)
      v <- strsplit(paste0(lines[j],",END"),",",fixed=TRUE)[[1]]
      stopifnot(length(v)==length(raw)+1L)
      out[match(id[j],mapping$ModelID),] <- as.numeric(v[take])
      seen <- c(seen,id[j])
    }
    if(length(seen)==nrow(mapping)) break
  }
  hits <- which(is.finite(out), arr.ind=TRUE)
  data.frame(model=mapping$model[hits[,1]], gene=genes[hits[,2]],
             entrez_id=ids[hits[,2]], metric=metric, value=out[hits])
}
x <- rbind(subset_matrix("CRISPRGeneEffect.csv","CRISPR gene effect"),
           subset_matrix("OmicsExpressionProteinCodingGenesTPMLogp1.csv","RNA log2(TPM + 1)"))
con <- gzfile("data/depmap_values.csv.gz","wt")
write.csv(x,con,row.names=FALSE)
close(con)
print(aggregate(value~model+metric,x,length))
