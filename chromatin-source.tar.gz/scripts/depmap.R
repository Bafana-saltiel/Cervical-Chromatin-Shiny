# Rscript scripts/depmap.R [release-download-directory]
args <- commandArgs(trailingOnly=TRUE)
cache <- if(length(args)) args[1] else tempfile("depmap-")
dir.create(cache,showWarnings=FALSE,recursive=TRUE)
source <- read.csv("data/depmap_sources.csv")
for(i in seq_len(nrow(source))){
  path <- file.path(cache,source$file[i])
  if(!file.exists(path)){
    options(timeout=300)
    download.file(source$url[i],path,mode="wb")
  }
  stopifnot(unname(tools::md5sum(path))==source$md5[i])
}
models <- read.csv(file.path(cache,"Model.csv"),check.names=FALSE)
mapping <- data.frame(model=c("SiHa","CaSki","C33A"),
                      ModelID=c("ACH-000556","ACH-001336","ACH-001333"))
ids <- match(mapping$ModelID,models$ModelID)
stopifnot(!anyNA(ids),identical(models$StrippedCellLineName[ids],c("SIHA","CASKI","C33A")))
meta <- cbind(mapping,models[ids,c("CellLineName","OncotreePrimaryDisease","RRID","CCLEName")])
write.csv(meta,"data/depmap_models.csv",row.names=FALSE)
genes <- sort(unique(read.csv("data/Review_3D_coordinates.csv")$gene))
subset_matrix <- function(file,metric) {
  con <- file(file.path(cache,file),"rt")
  on.exit(close(con))
  raw <- strsplit(readLines(con,n=1L),",",fixed=TRUE)[[1]]
  symbols <- sub(" \\([0-9]+\\)$","",raw)
  take <- match(genes,symbols)
  stopifnot(!anyDuplicated(take[!is.na(take)]))
  out <- matrix(NA_real_,nrow(mapping),length(genes))
  seen <- character()
  repeat {
    lines <- readLines(con,n=80L)
    if(!length(lines)) break
    id <- sub(",.*","",lines)
    needed <- which(id %in% mapping$ModelID)
    for (j in needed) {
      stopifnot(!id[j] %in% seen)
      v <- strsplit(paste0(lines[j],",END"),",",fixed=TRUE)[[1]]
      stopifnot(length(v)==length(raw)+1L)
      out[match(id[j],mapping$ModelID),] <- as.numeric(v[take])
      seen <- c(seen,id[j])
    }
    if(length(seen)==nrow(mapping)) break
  }
  data.frame(model=rep(mapping$model,each=length(genes)),
             gene=rep(genes,times=nrow(mapping)),metric=metric,value=as.vector(t(out)))
}
x <- rbind(subset_matrix("CRISPRGeneEffect.csv","CRISPR gene effect"),
           subset_matrix("OmicsExpressionProteinCodingGenesTPMLogp1.csv","RNA log2(TPM + 1)"))
write.csv(x,"data/depmap_values.csv",row.names=FALSE)
print(aggregate(is.finite(value)~model+metric,x,sum))
