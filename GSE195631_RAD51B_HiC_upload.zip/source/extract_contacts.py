import csv,sys,os
import hicstraw
import numpy as np
name, accession=sys.argv[1:]
url=f'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM6658nnn/{accession}/suppl/{accession}_{name}.allValidPairs.hic'
resolution=25000; start=65250000; end=70500000
f=hicstraw.HiCFile(url)
chrom=next(c.name for c in f.getChromosomes() if c.name in ('14','chr14'))
m=f.getMatrixZoomData(chrom,chrom,'observed','NONE','BP',resolution)
records=m.getRecords(start,end-1,start,end-1)
n=(end-start)//resolution
raw=np.zeros((n,n))
for r in records:
 if start<=r.binX<end and start<=r.binY<end:
  i,j=(r.binX-start)//resolution,(r.binY-start)//resolution
  raw[i,j]=raw[j,i]=r.counts
assert np.count_nonzero(np.triu(raw,2)) > 500
dist=np.abs(np.arange(n)[:,None]-np.arange(n))
core=np.where(dist>=2,raw,0)
keep=np.count_nonzero(core,axis=1)>=10
idx=np.flatnonzero(keep)
assert keep[(67750000-start)//resolution] and keep[(68750000-start)//resolution]
c=core[np.ix_(idx,idx)]
weights=np.ones(len(idx))
for iteration in range(500):
 margin=weights*(c@weights)
 if np.max(np.abs(margin/np.mean(margin)-1))<1e-5: break
 weights/=np.sqrt(margin/np.mean(margin))
else: raise ValueError('Local balancing failed to converge')
weights/=np.sqrt(np.mean(weights*(c@weights)))
values=raw[np.ix_(idx,idx)]*np.outer(weights,weights)
with open(f'{name}.ICE.csv.tmp','w') as o:
 w=csv.writer(o)
 for i,a in enumerate(idx):
  for j,b in enumerate(idx[i:],start=i):
   w.writerow((accession,'chr14',start+a*resolution,start+b*resolution,format(values[i,j],'.9g')))
os.replace(f'{name}.ICE.csv.tmp',f'{name}.ICE.csv')
print(name,len(records),len(idx),iteration)
