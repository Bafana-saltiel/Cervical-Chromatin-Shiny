GSE195631 cervical cell-line RAD51B upload bundle
================================================
Source: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE195631
Coordinates: GRCh38, zero-based, half-open chr14:65,250,000–70,500,000
Resolution: 25,000 bp. This window includes RAD51B (TSS 67,819,778)
and the 68.75 Mb region identified in the separate HeLa-S3 experiment.

Upload into Hi-C reanalysis > Upload study
  Contacts: RAD51B_cervical_contacts_25kb.csv.gz (leave compressed)
  Sample metadata: samples_GRCh38.csv
  Gene or DEG lists: RAD51B_GRCh38.csv
  Optional CTCF or enhancer BED4: choose one *_H3K27ac_GRCh38.bed
  Leave the optional A/B phasing track empty.

Start with HeLa as reference and CaSki as comparison, then select RAD51B.
Use the app's flank control to zoom. Download reanalysis ZIP for tracks,
annotations, promoter profiles, contact candidates and figures.

Time 0 and replicate 1 are placeholders required by the upload form. These
are baseline cell-line maps, not a time series or replicate comparison.
The assays are matched by cell-line identity rather than sample aliquot.
The 68.75 Mb region is included for exploration, without assuming that the
HeLa-S3 interaction recurs at 25 kb resolution in these baseline samples.

Contacts were extracted from the five GEO .hic maps with hic-straw using
raw cis counts. All five windows were balanced separately using iterative
correction, excluding diagonal offsets 0 and 1 when estimating weights.
The export contains the full upper triangle, including explicit zeros.
Balances and expected contacts are local to this window, so absolute signal,
boundaries and PC1 should be interpreted in that context. This is a regional
example. Unphased PC1 signs are not A/B labels and focal contacts are candidate
interactions rather than significance-tested loops.

H3K27ac files use published MACS peak intervals converted to BED4. The app
applies one uploaded peak track to all displayed maps as an annotation
reference. Use the matching cell-line BED when interpreting overlaps for that
line. RAD51B_expression_context.csv comes from the deposited RNA-seq tables and
is for joining by cell line outside the Hi-C upload form. The source manifest
has direct links to the original maps, RNA-seq, peaks and WGBS cytosine calls.
WGBS cytosine calls have not been summarized or included in the upload files.
GSE176066 is a separate dataset and is not mixed with these GRCh38 inputs.

For publication-scale cervical analysis, keep whole-chromosome .hic files
or convert to sparse .cool/.mcool (hictk or equivalent). Use cooler balancing
with QC masks, cooltools insulation and phased eigs-cis on entire chromosomes,
then expected-cis and promoter-centred virtual 4C. For genome-wide loop calling,
use cooltools dots or Juicer HiCCUPS after checking map depth. Link focal calls
to promoters and overlap independently matched regulatory tracks. Carry forward
every supplied gene record, marking bins with no usable data. Use biological
replicates for inferential comparisons. Import or display the outputs in
Shiny; the current app does not run those external engines on the server.

Methods references:
https://cooltools.readthedocs.io/en/latest/cli.html
https://hictk.readthedocs.io/en/latest/
